# Laravel Controller Architecture for AWS API Integration

## Overview
This document outlines the architecture for integrating the five AWS API microservices directly into the Laravel application. Instead of proxying requests to external AWS Lambda functions, we will implement the functionality directly in Laravel controllers.

## Architecture Design

### 1. Controller Structure
We will create dedicated controller classes for each microservice while maintaining the existing proxy infrastructure:

```
app/Http/Controllers/
├── AWS/
│   ├── ContentTransformationController.php
│   ├── MeetingAssistantController.php
│   ├── VoiceGenerationController.php
│   ├── CustomerJourneyController.php
│   └── SyntheticDataController.php
├── MicroservicesController.php (existing proxy controller)
└── MicroservicesAnalyticsController.php (existing analytics controller)
```

### 2. Service Layer
To separate business logic from controllers, we'll create service classes for each microservice:

```
app/Services/
├── AWS/
│   ├── ContentTransformationService.php
│   ├── MeetingAssistantService.php
│   ├── VoiceGenerationService.php
│   ├── CustomerJourneyService.php
│   └── SyntheticDataService.php
```

### 3. Route Configuration
We'll maintain the existing route structure but add new routes that point to our direct implementation:

```php
// Content Transformation API routes
Route::prefix('api/transform')->group(function () {
    Route::post('/text-to-speech', [ContentTransformationController::class, 'textToSpeech']);
    Route::post('/speech-to-text', [ContentTransformationController::class, 'speechToText']);
    // Additional endpoints...
});
```

### 4. Middleware Integration
We'll leverage the existing middleware for authentication, rate limiting, and credit deduction:

```php
Route::middleware(['auth:api', 'microservices.ratelimit', 'microservices.credits'])
    ->prefix('api/transform')
    ->group(function () {
        // Routes...
    });
```

### 5. AWS SDK Integration
For AWS services that still need to be used (S3, DynamoDB, etc.), we'll create facade classes:

```
app/Facades/
├── AWS/
│   ├── S3Facade.php
│   ├── DynamoDBFacade.php
│   ├── PollyFacade.php
│   └── ComprehendFacade.php
```

### 6. Database Integration
We'll create Laravel models and migrations for the data previously stored in DynamoDB:

```
app/Models/
├── ContentTransformation/
│   ├── TransformationJob.php
├── MeetingAssistant/
│   ├── Meeting.php
│   ├── Transcript.php
│   ├── Action.php
├── VoiceGeneration/
│   ├── VoiceProfile.php
│   ├── VoiceJob.php
├── CustomerJourney/
│   ├── User.php
│   ├── Journey.php
│   ├── Touchpoint.php
│   ├── Event.php
├── SyntheticData/
│   ├── Dataset.php
│   ├── Schema.php
│   ├── Job.php
```

### 7. Configuration
We'll add configuration files for each microservice:

```
config/
├── content_transformation.php
├── meeting_assistant.php
├── voice_generation.php
├── customer_journey.php
├── synthetic_data.php
```

## Implementation Strategy

1. **Phased Approach**: Implement one microservice at a time, starting with Content Transformation API.
2. **Backward Compatibility**: Maintain the existing proxy endpoints during transition.
3. **Feature Parity**: Ensure all features from the AWS Lambda functions are implemented.
4. **Testing**: Create comprehensive tests for each endpoint.
5. **Documentation**: Update API documentation to reflect the new implementation.

## Cost Tracking
We'll implement a cost tracking system that logs the estimated cost of each API call:

```php
// In each service method
$this->costTracker->logOperation('text-to-speech', [
    'input_size' => strlen($request->text),
    'output_format' => $request->format
]);
```

## Integration with Frontend
The frontend will continue to use the same API endpoints, ensuring a seamless transition.

## Deployment Strategy
1. Deploy the new controllers alongside the existing proxy.
2. Gradually switch traffic from proxy to direct implementation.
3. Monitor performance and costs.
4. Once stable, remove the proxy implementation.
