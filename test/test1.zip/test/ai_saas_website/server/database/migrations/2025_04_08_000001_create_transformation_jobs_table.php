<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransformationJobsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transformation_jobs', function (Blueprint $table) {
            $table->uuid('job_id')->primary();
            $table->string('type');
            $table->string('status');
            $table->json('input');
            $table->json('output')->nullable();
            $table->text('error')->nullable();
            $table->timestamp('created_at');
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transformation_jobs');
    }
}
