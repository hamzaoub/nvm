<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMeetingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('meetings', function (Blueprint $table) {
            $table->uuid('meeting_id')->primary();
            $table->string('title');
            $table->string('status');
            $table->string('audio_url');
            $table->float('duration')->nullable();
            $table->json('participants')->nullable();
            $table->json('metadata')->nullable();
            $table->text('summary')->nullable();
            $table->integer('action_count')->default(0);
            $table->string('language')->nullable();
            $table->timestamp('created_at');
            $table->timestamp('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('meetings');
    }
}
