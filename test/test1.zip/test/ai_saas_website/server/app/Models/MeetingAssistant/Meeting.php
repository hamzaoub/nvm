<?php

namespace App\Models\MeetingAssistant;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Meeting extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'meetings';

    /**
     * The primary key for the model.
     *
     * @var string
     */
    protected $primaryKey = 'meeting_id';

    /**
     * The "type" of the primary key ID.
     *
     * @var string
     */
    protected $keyType = 'string';

    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'meeting_id',
        'title',
        'status',
        'audio_url',
        'duration',
        'participants',
        'metadata',
        'summary',
        'action_count',
        'language',
        'created_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'participants' => 'array',
        'metadata' => 'array',
        'duration' => 'float',
        'action_count' => 'integer',
        'created_at' => 'datetime',
    ];

    /**
     * Get the transcript for the meeting.
     */
    public function transcript()
    {
        return $this->hasOne(Transcript::class, 'meeting_id', 'meeting_id');
    }

    /**
     * Get the actions for the meeting.
     */
    public function actions()
    {
        return $this->hasMany(Action::class, 'meeting_id', 'meeting_id');
    }
}
