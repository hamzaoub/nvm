<?php

namespace App\Http\Controllers\AWS;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\AWS\SyntheticDataService;
use Illuminate\Support\Facades\Validator;

class SyntheticDataController extends Controller
{
    protected $syntheticDataService;

    /**
     * Create a new controller instance.
     *
     * @param SyntheticDataService $syntheticDataService
     * @return void
     */
    public function __construct(SyntheticDataService $syntheticDataService)
    {
        $this->syntheticDataService = $syntheticDataService;
    }

    /**
     * Generate synthetic tabular data
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function generateTabularData(Request $request)
    {
        // Validate request
        $validator = Validator::make($request->all(), [
            'schema' => 'required|array',
            'rows' => 'integer|min:1|max:10000',
            'constraints' => 'array',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 400);
        }

        try {
            // Extract parameters
            $schema = $request->input('schema');
            $rows = $request->input('rows', 100);
            $constraints = $request->input('constraints', []);

            // Generate data
            $result = $this->syntheticDataService->generateTabularData($schema, $rows, $constraints);

            // Track cost
            $this->syntheticDataService->trackCost('generate-tabular-data', [
                'rows' => $rows,
                'columns' => count($schema),
            ]);

            return response()->json([
                'status' => 'success',
                'data' => $result,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to generate tabular data: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Generate synthetic text data
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function generateTextData(Request $request)
    {
        // Validate request
        $validator = Validator::make($request->all(), [
            'prompt' => 'required|string|max:1000',
            'category' => 'string|in:general,product_reviews,news_articles,social_media,customer_support,medical,legal',
            'count' => 'integer|min:1|max:50',
            'max_length' => 'integer|min:10|max:2000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 400);
        }

        try {
            // Extract parameters
            $prompt = $request->input('prompt');
            $category = $request->input('category', 'general');
            $count = $request->input('count', 5);
            $maxLength = $request->input('max_length', 200);

            // Generate data
            $result = $this->syntheticDataService->generateTextData($prompt, $category, $count, $maxLength);

            // Track cost
            $this->syntheticDataService->trackCost('generate-text-data', [
                'count' => $count,
                'max_length' => $maxLength,
                'category' => $category,
            ]);

            return response()->json([
                'status' => 'success',
                'data' => $result,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to generate text data: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Generate synthetic image data
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function generateImageData(Request $request)
    {
        // Validate request
        $validator = Validator::make($request->all(), [
            'prompt' => 'required|string|max:1000',
            'style' => 'string|in:realistic,digital_art,anime,painting,sketch,watercolor,pixel_art,fantasy,sci_fi',
            'size' => 'string|in:256x256,512x512,1024x1024',
            'count' => 'integer|min:1|max:10',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 400);
        }

        try {
            // Extract parameters
            $prompt = $request->input('prompt');
            $style = $request->input('style', 'realistic');
            $size = $request->input('size', '512x512');
            $count = $request->input('count', 1);

            // Generate data
            $result = $this->syntheticDataService->generateImageData($prompt, $style, $size, $count);

            // Track cost
            $this->syntheticDataService->trackCost('generate-image-data', [
                'count' => $count,
                'size' => $size,
                'style' => $style,
            ]);

            return response()->json([
                'status' => 'success',
                'data' => $result,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to generate image data: ' . $e->getMessage(),
            ], 500);
        }
    }
}
