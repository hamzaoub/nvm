<?php

namespace App\Http\Controllers\AWS;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use App\Services\AWS\MeetingAssistantService;
use App\Models\MeetingAssistant\Meeting;
use App\Models\MeetingAssistant\Transcript;
use App\Models\MeetingAssistant\Action;
use Carbon\Carbon;

class MeetingAssistantController extends Controller
{
    protected $service;

    public function __construct(MeetingAssistantService $service)
    {
        $this->service = $service;
    }

    /**
     * Handle meeting transcription request
     */
    public function transcribeMeeting(Request $request)
    {
        // Validate request
        $request->validate([
            'audio_url' => 'required|url',
            'title' => 'nullable|string|max:255',
            'participants' => 'nullable|array',
            'media_format' => 'nullable|string|in:mp3,mp4,wav,flac',
            'language' => 'nullable|string',
            'metadata' => 'nullable|array',
        ]);

        // Create meeting record
        $meeting = new Meeting();
        $meeting->meeting_id = (string) Str::uuid();
        $meeting->status = 'transcribing';
        $meeting->created_at = Carbon::now();
        $meeting->audio_url = $request->audio_url;
        $meeting->title = $request->title ?? 'Untitled Meeting';
        $meeting->participants = $request->participants ?? [];
        $meeting->metadata = $request->metadata ?? [];
        $meeting->save();

        // Start transcription job
        try {
            $this->service->startTranscriptionJob(
                $meeting->meeting_id,
                $request->audio_url,
                $request->media_format ?? 'mp3',
                $request->language ?? 'en-US',
                count($request->participants ?? [])
            );

            // Track cost
            $this->service->trackCost('transcribe-meeting', [
                'media_format' => $request->media_format ?? 'mp3',
                'language' => $request->language ?? 'en-US',
            ]);

            return response()->json([
                'meeting_id' => $meeting->meeting_id,
                'status' => 'transcribing',
                'title' => $meeting->title
            ], 202);
        } catch (\Exception $e) {
            // Update meeting with error
            $meeting->status = 'failed';
            $meeting->save();

            Log::error("Meeting transcription failed: {$e->getMessage()}");
            return response()->json([
                'error' => 'Transcription failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Handle meeting summarization request
     */
    public function summarizeMeeting(Request $request)
    {
        // Validate request
        $request->validate([
            'meeting_id' => 'required|string',
        ]);

        // Get meeting transcript
        try {
            $transcript = Transcript::where('meeting_id', $request->meeting_id)->firstOrFail();
            
            // Update meeting status
            $meeting = Meeting::where('meeting_id', $request->meeting_id)->firstOrFail();
            $meeting->status = 'summarizing';
            $meeting->save();

            // Generate summary
            $summary = $this->service->generateSummary(
                $transcript->full_text,
                $meeting->language ?? 'en'
            );

            // Update meeting with summary
            $meeting->summary = $summary;
            $meeting->status = 'summarized';
            $meeting->save();

            // Track cost
            $this->service->trackCost('summarize-meeting', [
                'text_length' => strlen($transcript->full_text),
                'language' => $meeting->language ?? 'en',
            ]);

            return response()->json([
                'meeting_id' => $meeting->meeting_id,
                'summary' => $summary
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'error' => 'Transcript not found'
            ], 404);
        } catch (\Exception $e) {
            Log::error("Meeting summarization failed: {$e->getMessage()}");
            return response()->json([
                'error' => 'Summarization failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Handle action item extraction request
     */
    public function extractActions(Request $request)
    {
        // Validate request
        $request->validate([
            'meeting_id' => 'required|string',
        ]);

        // Get meeting transcript
        try {
            $transcript = Transcript::where('meeting_id', $request->meeting_id)->firstOrFail();
            
            if (empty($transcript->full_text)) {
                return response()->json([
                    'error' => 'No transcript text available for action extraction'
                ], 400);
            }

            // Extract action items
            $actionItems = $this->service->extractActionItems(
                $transcript->full_text,
                $request->meeting_id
            );

            // Update meeting with action count
            $meeting = Meeting::where('meeting_id', $request->meeting_id)->first();
            if ($meeting) {
                $meeting->action_count = count($actionItems);
                $meeting->save();
            }

            // Track cost
            $this->service->trackCost('extract-actions', [
                'text_length' => strlen($transcript->full_text),
            ]);

            return response()->json([
                'meeting_id' => $request->meeting_id,
                'action_items' => $actionItems,
                'count' => count($actionItems)
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'error' => 'Transcript not found'
            ], 404);
        } catch (\Exception $e) {
            Log::error("Action item extraction failed: {$e->getMessage()}");
            return response()->json([
                'error' => 'Action extraction failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Handle follow-up generation request
     */
    public function generateFollowup(Request $request)
    {
        // Validate request
        $request->validate([
            'meeting_id' => 'required|string',
        ]);

        try {
            // Get action items for the meeting
            $actions = Action::where('meeting_id', $request->meeting_id)->get();
            
            if ($actions->isEmpty()) {
                return response()->json([
                    'error' => 'No action items found for this meeting'
                ], 404);
            }

            // Get meeting details
            $meeting = Meeting::where('meeting_id', $request->meeting_id)->firstOrFail();

            // Generate follow-up messages
            $followups = $this->service->generateFollowupMessages($actions, $meeting);

            // Track cost
            $this->service->trackCost('generate-followup', [
                'action_count' => $actions->count(),
            ]);

            return response()->json([
                'meeting_id' => $request->meeting_id,
                'followups' => $followups
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'error' => 'Meeting not found'
            ], 404);
        } catch (\Exception $e) {
            Log::error("Follow-up generation failed: {$e->getMessage()}");
            return response()->json([
                'error' => 'Follow-up generation failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Handle meeting search request
     */
    public function searchMeetings(Request $request)
    {
        // Validate request
        if (empty($request->query('query')) && empty($request->query('date'))) {
            return response()->json([
                'error' => 'Missing required parameter: query or date'
            ], 400);
        }

        try {
            $meetings = [];

            // If searching by date
            if ($request->has('date')) {
                $date = $request->query('date');
                $meetings = Meeting::where('created_at', 'like', $date . '%')->get();
            }
            
            // If searching by text query
            if ($request->has('query')) {
                $query = $request->query('query');
                
                // Search in meeting titles and summaries
                $titleMatches = Meeting::where('title', 'like', '%' . $query . '%')
                    ->orWhere('summary', 'like', '%' . $query . '%')
                    ->get();
                
                // Search in transcripts
                $transcriptMatches = Transcript::where('full_text', 'like', '%' . $query . '%')->get();
                $meetingIdsFromTranscripts = $transcriptMatches->pluck('meeting_id')->toArray();
                
                // Get meetings from transcript matches that weren't already included
                $meetingIdsAlreadyIncluded = $titleMatches->pluck('meeting_id')->toArray();
                $additionalMeetings = Meeting::whereIn('meeting_id', $meetingIdsFromTranscripts)
                    ->whereNotIn('meeting_id', $meetingIdsAlreadyIncluded)
                    ->get();
                
                // Combine results
                $meetings = $titleMatches->merge($additionalMeetings);
            }

            return response()->json([
                'meetings' => $meetings,
                'count' => count($meetings)
            ]);
        } catch (\Exception $e) {
            Log::error("Meeting search failed: {$e->getMessage()}");
            return response()->json([
                'error' => 'Search failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get meeting details
     */
    public function getMeeting(Request $request, $meetingId)
    {
        try {
            // Get meeting details
            $meeting = Meeting::where('meeting_id', $meetingId)->firstOrFail();
            
            // Get transcript if available
            $transcript = Transcript::where('meeting_id', $meetingId)->first();
            if ($transcript) {
                $meeting->transcript = $transcript;
            }
            
            // Get action items if available
            $actions = Action::where('meeting_id', $meetingId)->get();
            if ($actions->isNotEmpty()) {
                $meeting->action_items = $actions;
            }
            
            return response()->json($meeting);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'error' => 'Meeting not found'
            ], 404);
        } catch (\Exception $e) {
            Log::error("Error retrieving meeting: {$e->getMessage()}");
            return response()->json([
                'error' => 'Failed to retrieve meeting',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
