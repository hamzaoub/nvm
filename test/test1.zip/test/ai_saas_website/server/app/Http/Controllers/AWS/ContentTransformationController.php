<?php

namespace App\Http\Controllers\AWS;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use App\Services\AWS\ContentTransformationService;
use App\Models\ContentTransformation\TransformationJob;
use Carbon\Carbon;

class ContentTransformationController extends Controller
{
    protected $service;

    public function __construct(ContentTransformationService $service)
    {
        $this->service = $service;
    }

    /**
     * Handle text-to-speech transformation
     */
    public function textToSpeech(Request $request)
    {
        // Validate request
        $request->validate([
            'text' => 'required|string|max:10000',
            'voice' => 'nullable|string',
            'format' => 'nullable|string|in:mp3,ogg,pcm',
            'speed' => 'nullable|numeric|between:0.5,2.0',
        ]);

        // Create job record
        $job = new TransformationJob();
        $job->job_id = (string) Str::uuid();
        $job->type = 'text-to-speech';
        $job->status = 'processing';
        $job->created_at = Carbon::now();
        $job->input = [
            'text' => $request->text,
            'voice' => $request->voice ?? 'default',
            'format' => $request->format ?? 'mp3',
            'speed' => $request->speed ?? 1.0,
        ];
        $job->save();

        // Process the transformation
        try {
            $result = $this->service->transformTextToSpeech(
                $request->text,
                $request->voice ?? 'default',
                $request->format ?? 'mp3',
                $request->speed ?? 1.0
            );

            // Update job with result
            $job->status = 'completed';
            $job->output = [
                'audio_url' => $result['audio_url'],
                'duration' => $result['duration'],
                'format' => $result['format'],
            ];
            $job->completed_at = Carbon::now();
            $job->save();

            // Track cost
            $this->service->trackCost('text-to-speech', [
                'text_length' => strlen($request->text),
                'format' => $request->format ?? 'mp3',
            ]);

            return response()->json([
                'job_id' => $job->job_id,
                'status' => 'completed',
                'audio_url' => $result['audio_url'],
                'duration' => $result['duration'],
            ]);
        } catch (\Exception $e) {
            // Update job with error
            $job->status = 'failed';
            $job->error = $e->getMessage();
            $job->save();

            Log::error("Text-to-speech transformation failed: {$e->getMessage()}");
            return response()->json([
                'error' => 'Transformation failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Handle speech-to-text transformation
     */
    public function speechToText(Request $request)
    {
        // Validate request
        $request->validate([
            'audio' => 'required|file|mimes:mp3,wav,ogg,m4a|max:20000',
            'language' => 'nullable|string',
        ]);

        // Create job record
        $job = new TransformationJob();
        $job->job_id = (string) Str::uuid();
        $job->type = 'speech-to-text';
        $job->status = 'processing';
        $job->created_at = Carbon::now();
        $job->input = [
            'filename' => $request->file('audio')->getClientOriginalName(),
            'language' => $request->language ?? 'en-US',
        ];
        $job->save();

        // Process the transformation
        try {
            // Store the uploaded file
            $path = $request->file('audio')->store('audio_inputs');
            $audioUrl = Storage::url($path);

            // Perform the transformation
            $result = $this->service->transformSpeechToText(
                storage_path('app/' . $path),
                $request->language ?? 'en-US'
            );

            // Update job with result
            $job->status = 'completed';
            $job->output = [
                'text' => $result['text'],
                'confidence' => $result['confidence'],
                'language' => $result['language'],
                'audio_url' => $audioUrl,
            ];
            $job->completed_at = Carbon::now();
            $job->save();

            // Track cost
            $this->service->trackCost('speech-to-text', [
                'audio_duration' => $result['duration'],
                'language' => $request->language ?? 'en-US',
            ]);

            return response()->json([
                'job_id' => $job->job_id,
                'status' => 'completed',
                'text' => $result['text'],
                'confidence' => $result['confidence'],
            ]);
        } catch (\Exception $e) {
            // Update job with error
            $job->status = 'failed';
            $job->error = $e->getMessage();
            $job->save();

            Log::error("Speech-to-text transformation failed: {$e->getMessage()}");
            return response()->json([
                'error' => 'Transformation failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Handle text-to-image transformation
     */
    public function textToImage(Request $request)
    {
        // Validate request
        $request->validate([
            'text' => 'required|string|max:1000',
            'style' => 'nullable|string',
            'size' => 'nullable|string|in:256x256,512x512,1024x1024',
        ]);

        // Create job record
        $job = new TransformationJob();
        $job->job_id = (string) Str::uuid();
        $job->type = 'text-to-image';
        $job->status = 'processing';
        $job->created_at = Carbon::now();
        $job->input = [
            'text' => $request->text,
            'style' => $request->style ?? 'default',
            'size' => $request->size ?? '512x512',
        ];
        $job->save();

        // Process the transformation
        try {
            $result = $this->service->transformTextToImage(
                $request->text,
                $request->style ?? 'default',
                $request->size ?? '512x512'
            );

            // Update job with result
            $job->status = 'completed';
            $job->output = [
                'image_url' => $result['image_url'],
                'size' => $result['size'],
                'format' => $result['format'],
            ];
            $job->completed_at = Carbon::now();
            $job->save();

            // Track cost
            $this->service->trackCost('text-to-image', [
                'text_length' => strlen($request->text),
                'size' => $request->size ?? '512x512',
            ]);

            return response()->json([
                'job_id' => $job->job_id,
                'status' => 'completed',
                'image_url' => $result['image_url'],
            ]);
        } catch (\Exception $e) {
            // Update job with error
            $job->status = 'failed';
            $job->error = $e->getMessage();
            $job->save();

            Log::error("Text-to-image transformation failed: {$e->getMessage()}");
            return response()->json([
                'error' => 'Transformation failed',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get job status
     */
    public function getJobStatus(Request $request, $jobId)
    {
        try {
            $job = TransformationJob::where('job_id', $jobId)->firstOrFail();
            
            return response()->json([
                'job_id' => $job->job_id,
                'type' => $job->type,
                'status' => $job->status,
                'created_at' => $job->created_at->toIso8601String(),
                'completed_at' => $job->completed_at ? $job->completed_at->toIso8601String() : null,
                'output' => $job->status === 'completed' ? $job->output : null,
                'error' => $job->status === 'failed' ? $job->error : null,
            ]);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json([
                'error' => 'Job not found'
            ], 404);
        } catch (\Exception $e) {
            Log::error("Error retrieving job status: {$e->getMessage()}");
            return response()->json([
                'error' => 'Failed to retrieve job status',
                'message' => $e->getMessage()
            ], 500);
        }
    }
}
