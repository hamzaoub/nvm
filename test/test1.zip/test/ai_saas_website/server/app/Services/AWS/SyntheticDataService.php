<?php

namespace App\Services\AWS;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Models\CostTracking\OperationCost;
use Carbon\Carbon;

class SyntheticDataService
{
    /**
     * Generate synthetic tabular data
     *
     * @param array $schema The data schema
     * @param int $rows The number of rows to generate
     * @param array $constraints The data constraints
     * @return array The generated data
     */
    public function generateTabularData(array $schema, int $rows = 100, array $constraints = []): array
    {
        // Use Gretel API for synthetic data generation
        $apiKey = config('services.gretel.key');
        $endpoint = 'https://api.gretel.cloud/synthetics/tabular';
        
        // Prepare request
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'schema' => $schema,
            'num_records' => $rows,
            'constraints' => $constraints,
            'model_config' => [
                'model_type' => 'amplify',
                'privacy_guarantees' => [
                    'enabled' => true,
                    'epsilon' => 1.0
                ]
            ]
        ]);
        
        if (!$response->successful()) {
            // Fallback to local generation if API fails
            return $this->generateLocalTabularData($schema, $rows, $constraints);
        }
        
        $jobId = $response->json()['job_id'];
        
        // Poll for completion
        $complete = false;
        $maxAttempts = 30;
        $attempts = 0;
        $result = null;
        
        while (!$complete && $attempts < $maxAttempts) {
            sleep(5); // Wait 5 seconds between polls
            
            $statusResponse = Http::withHeaders([
                'Authorization' => 'Bearer ' . $apiKey,
            ])->get("{$endpoint}/{$jobId}");
            
            if (!$statusResponse->successful()) {
                $attempts++;
                continue;
            }
            
            $status = $statusResponse->json()['status'];
            
            if ($status === 'completed') {
                $complete = true;
                $result = $statusResponse->json()['result'];
            } elseif ($status === 'failed') {
                // Fallback to local generation
                return $this->generateLocalTabularData($schema, $rows, $constraints);
            } else {
                $attempts++;
            }
        }
        
        if (!$complete) {
            // Fallback to local generation if timeout
            return $this->generateLocalTabularData($schema, $rows, $constraints);
        }
        
        // Save to S3
        $fileName = 'synthetic_data_' . uniqid() . '.csv';
        $path = 'synthetic_data/' . $fileName;
        
        Storage::put($path, $result['data_csv']);
        
        // Generate download URL
        $downloadUrl = Storage::url($path);
        
        // Track cost
        $this->trackCost('generate-tabular-data', [
            'rows' => $rows,
            'columns' => count($schema),
        ]);
        
        return [
            'data' => $result['data'],
            'download_url' => $downloadUrl,
            'row_count' => $rows,
            'column_count' => count($schema),
        ];
    }
    
    /**
     * Generate synthetic text data
     *
     * @param string $prompt The generation prompt
     * @param string $category The text category
     * @param int $count The number of texts to generate
     * @param int $maxLength The maximum length of each text
     * @return array The generated text data
     */
    public function generateTextData(string $prompt, string $category = 'general', int $count = 5, int $maxLength = 200): array
    {
        // Use OpenAI API for text generation
        $apiKey = config('services.openai.key');
        $endpoint = 'https://api.openai.com/v1/chat/completions';
        
        // Prepare system prompt based on category
        $systemPrompt = $this->getSystemPromptForCategory($category);
        
        // Prepare request
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => $systemPrompt
                ],
                [
                    'role' => 'user',
                    'content' => "Generate {$count} unique examples of {$category} text based on this prompt: {$prompt}. Each example should be no longer than {$maxLength} characters. Format the response as a JSON array with each text as a separate item."
                ]
            ],
            'temperature' => 0.7,
            'max_tokens' => 1000,
        ]);
        
        if (!$response->successful()) {
            // Fallback to local generation
            return $this->generateLocalTextData($prompt, $category, $count, $maxLength);
        }
        
        $aiResponse = $response->json();
        $generatedText = $aiResponse['choices'][0]['message']['content'] ?? '';
        
        // Parse JSON from response
        $texts = $this->parseJsonFromText($generatedText);
        
        if (empty($texts)) {
            // Fallback to local generation if parsing fails
            return $this->generateLocalTextData($prompt, $category, $count, $maxLength);
        }
        
        // Track cost
        $this->trackCost('generate-text-data', [
            'count' => $count,
            'max_length' => $maxLength,
            'category' => $category,
        ]);
        
        return [
            'texts' => $texts,
            'count' => count($texts),
            'category' => $category,
            'prompt' => $prompt,
        ];
    }
    
    /**
     * Generate synthetic image data
     *
     * @param string $prompt The generation prompt
     * @param string $style The image style
     * @param string $size The image size
     * @param int $count The number of images to generate
     * @return array The generated image data
     */
    public function generateImageData(string $prompt, string $style = 'realistic', string $size = '512x512', int $count = 1): array
    {
        // Use Replicate API for image generation
        $apiKey = config('services.replicate.key');
        $endpoint = 'https://api.replicate.com/v1/predictions';
        
        // Parse size
        list($width, $height) = explode('x', $size);
        
        // Map style to a prompt suffix
        $styleSuffix = $this->mapStyleToPromptSuffix($style);
        $fullPrompt = $prompt . ($style !== 'default' ? ", {$styleSuffix}" : "");
        
        $images = [];
        
        // Generate each image
        for ($i = 0; $i < $count; $i++) {
            // Prepare request
            $response = Http::withHeaders([
                'Authorization' => 'Token ' . $apiKey,
                'Content-Type' => 'application/json',
            ])->post($endpoint, [
                'version' => 'db21e45d3f7023abc2a46ee38a23973f6dce16bb082a930b0c49861f96d1e5bf',
                'input' => [
                    'prompt' => $fullPrompt,
                    'negative_prompt' => 'blurry, bad quality, distorted, disfigured',
                    'width' => (int)$width,
                    'height' => (int)$height,
                    'num_outputs' => 1,
                    'guidance_scale' => 7.5,
                    'scheduler' => 'DPMSolverMultistep',
                    'num_inference_steps' => 25
                ]
            ]);
            
            if (!$response->successful()) {
                continue; // Skip this image if generation fails
            }
            
            $predictionId = $response->json()['id'];
            
            // Poll for completion
            $complete = false;
            $maxAttempts = 30;
            $attempts = 0;
            $result = null;
            
            while (!$complete && $attempts < $maxAttempts) {
                sleep(2); // Wait 2 seconds between polls
                
                $statusResponse = Http::withHeaders([
                    'Authorization' => 'Token ' . $apiKey,
                ])->get("{$endpoint}/{$predictionId}");
                
                if (!$statusResponse->successful()) {
                    $attempts++;
                    continue;
                }
                
                $status = $statusResponse->json()['status'];
                
                if ($status === 'succeeded') {
                    $complete = true;
                    $result = $statusResponse->json()['output'];
                } elseif ($status === 'failed') {
                    break; // Skip this image
                } else {
                    $attempts++;
                }
            }
            
            if (!$complete || !$result) {
                continue; // Skip this image
            }
            
            // Download the image and save to storage
            $imageUrl = $result[0] ?? null;
            if (!$imageUrl) {
                continue;
            }
            
            $imageResponse = Http::get($imageUrl);
            if (!$imageResponse->successful()) {
                continue;
            }
            
            $imageData = $imageResponse->body();
            $fileName = 'synthetic_image_' . uniqid() . '.png';
            $path = 'synthetic_images/' . $fileName;
            
            Storage::put($path, $imageData);
            
            // Generate public URL
            $storedImageUrl = Storage::url($path);
            
            $images[] = [
                'url' => $storedImageUrl,
                'size' => $size,
                'format' => 'png',
            ];
        }
        
        // Track cost
        $this->trackCost('generate-image-data', [
            'count' => count($images),
            'size' => $size,
            'style' => $style,
        ]);
        
        return [
            'images' => $images,
            'count' => count($images),
            'prompt' => $prompt,
            'style' => $style,
        ];
    }
    
    /**
     * Generate local tabular data
     *
     * @param array $schema The data schema
     * @param int $rows The number of rows to generate
     * @param array $constraints The data constraints
     * @return array The generated data
     */
    private function generateLocalTabularData(array $schema, int $rows, array $constraints): array
    {
        $data = [];
        
        // Generate rows
        for ($i = 0; $i < $rows; $i++) {
            $row = [];
            
            // Generate values for each column
            foreach ($schema as $column) {
                $name = $column['name'];
                $type = $column['type'];
                
                $row[$name] = $this->generateRandomValueForType($type, $column);
            }
            
            $data[] = $row;
        }
        
        // Apply constraints (simplified)
        if (!empty($constraints)) {
            $data = $this->applyConstraints($data, $constraints);
        }
        
        // Convert to CSV
        $csv = $this->convertToCsv($data);
        
        // Save to S3
        $fileName = 'synthetic_data_' . uniqid() . '.csv';
        $path = 'synthetic_data/' . $fileName;
        
        Storage::put($path, $csv);
        
        // Generate download URL
        $downloadUrl = Storage::url($path);
        
        return [
            'data' => $data,
            'download_url' => $downloadUrl,
            'row_count' => count($data),
            'column_count' => count($schema),
        ];
    }
    
    /**
     * Generate local text data
     *
     * @param string $prompt The generation prompt
     * @param string $category The text category
     * @param int $count The number of texts to generate
     * @param int $maxLength The maximum length of each text
     * @return array The generated text data
     */
    private function generateLocalTextData(string $prompt, string $category, int $count, int $maxLength): array
    {
        $texts = [];
        
        // Generate placeholder texts
        for ($i = 0; $i < $count; $i++) {
            $texts[] = "Sample {$category} text #{$i + 1} based on: {$prompt}";
        }
        
        return [
            'texts' => $texts,
            'count' => count($texts),
            'category' => $category,
            'prompt' => $prompt,
        ];
    }
    
    /**
     * Generate random value for a data type
     *
     * @param string $type The data type
     * @param array $column The column definition
     * @return mixed The generated value
     */
    private function generateRandomValueForType(string $type, array $column): mixed
    {
        switch ($type) {
            case 'integer':
                $min = $column['min'] ?? 0;
                $max = $column['max'] ?? 100;
                return rand($min, $max);
                
            case 'float':
                $min = $column['min'] ?? 0;
                $max = $column['max'] ?? 100;
                $decimals = $column['decimals'] ?? 2;
                return round($min + mt_rand() / mt_getrandmax() * ($max - $min), $decimals);
                
            case 'boolean':
                return (bool)rand(0, 1);
                
            case 'date':
                $start = strtotime($column['min'] ?? '-1 year');
                $end = strtotime($column['max'] ?? 'now');
                return date('Y-m-d', rand($start, $end));
                
            case 'datetime':
                $start = strtotime($column['min'] ?? '-1 year');
                $end = strtotime($column['max'] ?? 'now');
                return date('Y-m-d H:i:s', rand($start, $end));
                
            case 'categorical':
                $categories = $column['categories'] ?? ['A', 'B', 'C'];
                return $categories[array_rand($categories)];
                
            case 'name':
                $firstNames = ['John', 'Jane', 'Michael', 'Emily', 'David', 'Sarah'];
                $lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller'];
                return $firstNames[array_rand($firstNames)] . ' ' . $lastNames[array_rand($lastNames)];
                
            case 'email':
                $domains = ['example.com', 'test.org', 'mail.net', 'domain.co'];
                $name = strtolower(str_replace(' ', '.', $this->generateRandomValueForType('name', [])));
                return $name . '@' . $domains[array_rand($domains)];
                
            case 'phone':
                return '+1' . rand(100, 999) . rand(100, 999) . rand(1000, 9999);
                
            case 'address':
                $streets = ['Main St', 'Oak Ave', 'Maple Rd', 'Washington Blvd', 'Park Lane'];
                $cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix'];
                $states = ['NY', 'CA', 'IL', 'TX', 'AZ'];
                return rand(100, 9999) . ' ' . $streets[array_rand($streets)] . ', ' . 
                       $cities[array_rand($cities)] . ', ' . $states[array_rand($states)];
                
            case 'text':
            default:
                $words = ['lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit'];
                $length = $column['length'] ?? rand(5, 15);
                $text = '';
                for ($i = 0; $i < $length; $i++) {
                    $text .= $words[array_rand($words)] . ' ';
                }
                return trim($text);
        }
    }
    
    /**
     * Apply constraints to generated data
     *
     * @param array $data The generated data
     * @param array $constraints The constraints to apply
     * @return array The constrained data
     */
    private function applyConstraints(array $data, array $constraints): array
    {
        // Simple implementation for common constraints
        foreach ($constraints as $constraint) {
            $type = $constraint['type'] ?? '';
            
            switch ($type) {
                case 'unique':
                    $column = $constraint['column'] ?? '';
                    if (!empty($column)) {
                        $data = $this->ensureUnique($data, $column);
                    }
                    break;
                    
                case 'correlation':
                    $column1 = $constraint['column1'] ?? '';
                    $column2 = $constraint['column2'] ?? '';
                    $strength = $constraint['strength'] ?? 0.5;
                    if (!empty($column1) && !empty($column2)) {
                        $data = $this->applyCorrelation($data, $column1, $column2, $strength);
                    }
                    break;
            }
        }
        
        return $data;
    }
    
    /**
     * Ensure unique values in a column
     *
     * @param array $data The data
     * @param string $column The column name
     * @return array The data with unique values
     */
    private function ensureUnique(array $data, string $column): array
    {
        $seen = [];
        
        foreach ($data as &$row) {
            if (isset($row[$column])) {
                $value = $row[$column];
                
                // If value already seen, generate a new one
                while (isset($seen[$value])) {
                    $value = $row[$column] . '_' . uniqid();
                }
                
                $row[$column] = $value;
                $seen[$value] = true;
            }
        }
        
        return $data;
    }
    
    /**
     * Apply correlation between two columns
     *
     * @param array $data The data
     * @param string $column1 The first column
     * @param string $column2 The second column
     * @param float $strength The correlation strength
     * @return array The data with correlation
     */
    private function applyCorrelation(array $data, string $column1, string $column2, float $strength): array
    {
        // Simplified implementation
        // In a real implementation, this would be more sophisticated
        
        foreach ($data as &$row) {
            if (isset($row[$column1]) && isset($row[$column2])) {
                // Apply correlation with probability based on strength
                if (mt_rand() / mt_getrandmax() < $strength) {
                    // Make column2 somewhat dependent on column1
                    if (is_numeric($row[$column1]) && is_numeric($row[$column2])) {
                        $row[$column2] = $row[$column1] * (0.8 + (mt_rand() / mt_getrandmax()) * 0.4);
                    }
                }
            }
        }
        
        return $data;
    }
    
    /**
     * Convert data to CSV
     *
     * @param array $data The data
     * @return string The CSV string
     */
    private function convertToCsv(array $data): string
    {
        if (empty($data)) {
            return '';
        }
        
        $output = fopen('php://temp', 'r+');
        
        // Write header
        fputcsv($output, array_keys($data[0]));
        
        // Write rows
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
        
        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);
        
        return $csv;
    }
    
    /**
     * Get system prompt for text category
     *
     * @param string $category The text category
     * @return string The system prompt
     */
    private function getSystemPromptForCategory(string $category): string
    {
        $prompts = [
            'general' => 'You are a synthetic data generator. Create realistic, diverse text examples that could be used for training AI models.',
            'product_reviews' => 'You are a synthetic data generator. Create realistic product reviews with varying sentiment, length, and detail.',
            'news_articles' => 'You are a synthetic data generator. Create realistic news article snippets with headlines and body text.',
            'social_media' => 'You are a synthetic data generator. Create realistic social media posts with varying styles, topics, and tones.',
            'customer_support' => 'You are a synthetic data generator. Create realistic customer support conversations with queries and responses.',
            'medical' => 'You are a synthetic data generator. Create realistic medical notes and reports with appropriate terminology.',
            'legal' => 'You are a synthetic data generator. Create realistic legal text snippets with appropriate terminology and structure.',
        ];
        
        return $prompts[$category] ?? $prompts['general'];
    }
    
    /**
     * Parse JSON from text
     *
     * @param string $text The text containing JSON
     * @return array The parsed JSON
     */
    private function parseJsonFromText(string $text): array
    {
        // Try to extract JSON array from text
        if (preg_match('/\[\s*{.*}\s*\]/s', $text, $matches)) {
            $jsonString = $matches[0];
            $data = json_decode($jsonString, true);
            
            if (json_last_error() === JSON_ERROR_NONE && is_array($data)) {
                return $data;
            }
        }
        
        // If no valid JSON array found, try to parse as lines
        $lines = explode("\n", $text);
        $texts = [];
        
        foreach ($lines as $line) {
            $line = trim($line);
            
            // Skip empty lines and lines that look like headers
            if (empty($line) || preg_match('/^[0-9]+\.|\*|\-/', $line)) {
                continue;
            }
            
            $texts[] = $line;
        }
        
        return array_map(function($text) {
            return ['text' => $text];
        }, $texts);
    }
    
    /**
     * Map style to prompt suffix for Stable Diffusion
     *
     * @param string $style The style name
     * @return string The prompt suffix
     */
    private function mapStyleToPromptSuffix(string $style): string
    {
        $styleMap = [
            'realistic' => 'photorealistic, high detail, 8k, professional photography',
            'digital_art' => 'digital art, vibrant colors, detailed, artstation',
            'anime' => 'anime style, manga, vibrant, detailed, studio ghibli',
            'painting' => 'oil painting, detailed brushwork, artistic, museum quality',
            'sketch' => 'pencil sketch, detailed, hand-drawn, black and white',
            'watercolor' => 'watercolor painting, soft colors, flowing, artistic',
            'pixel_art' => 'pixel art, 8-bit, retro game style',
            'fantasy' => 'fantasy art, magical, ethereal, detailed, vibrant',
            'sci_fi' => 'sci-fi, futuristic, technological, detailed, cinematic',
        ];
        
        return $styleMap[$style] ?? '';
    }
    
    /**
     * Track the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return void
     */
    public function trackCost(string $operation, array $parameters): void
    {
        $cost = $this->calculateOperationCost($operation, $parameters);
        
        // Log the cost
        $costTracking = new OperationCost();
        $costTracking->operation = $operation;
        $costTracking->parameters = $parameters;
        $costTracking->cost = $cost;
        $costTracking->timestamp = Carbon::now();
        $costTracking->service = 'synthetic-data';
        $costTracking->save();
        
        Log::info("Cost tracked for {$operation}: \${$cost}", $parameters);
    }
    
    /**
     * Calculate the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return float The cost in USD
     */
    private function calculateOperationCost(string $operation, array $parameters): float
    {
        switch ($operation) {
            case 'generate-tabular-data':
                // Gretel: $0.02 per 1000 rows
                $rows = $parameters['rows'] ?? 100;
                return ($rows / 1000) * 0.02;
                
            case 'generate-text-data':
                // OpenAI GPT-3.5: $0.0015 per 1K tokens, estimate 1K tokens per text
                $count = $parameters['count'] ?? 5;
                return 0.0015 * $count;
                
            case 'generate-image-data':
                // Replicate Stable Diffusion: $0.002 per image
                $count = $parameters['count'] ?? 1;
                return 0.002 * $count;
                
            default:
                return 0.0;
        }
    }
}
