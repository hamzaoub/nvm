<?php

namespace App\Services\AWS;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Models\CostTracking\OperationCost;
use App\Models\MeetingAssistant\Meeting;
use App\Models\MeetingAssistant\Transcript;
use App\Models\MeetingAssistant\Action;
use Carbon\Carbon;

class MeetingAssistantService
{
    /**
     * Start a transcription job for a meeting
     *
     * @param string $meetingId The meeting ID
     * @param string $audioUrl The URL of the audio file
     * @param string $mediaFormat The media format
     * @param string $language The language code
     * @param int $speakerCount The number of speakers
     * @return void
     */
    public function startTranscriptionJob(string $meetingId, string $audioUrl, string $mediaFormat = 'mp3', string $language = 'en-US', int $speakerCount = 2): void
    {
        // Download the audio file if it's a public URL
        $localPath = $this->downloadAudioFile($audioUrl);
        
        // Upload file to S3 for storage
        $s3Key = 'meeting_inputs/' . basename($localPath);
        $s3Bucket = config('services.aws.bucket');
        
        $s3 = app('aws')->createS3();
        $s3->putObject([
            'Bucket' => $s3Bucket,
            'Key' => $s3Key,
            'SourceFile' => $localPath,
        ]);
        
        // Start transcription using Deepgram API
        $apiKey = config('services.deepgram.key');
        $endpoint = 'https://api.deepgram.com/v1/listen';
        
        // Create a pre-signed URL for the S3 object
        $s3Url = $s3->createPresignedRequest(
            $s3->getCommand('GetObject', [
                'Bucket' => $s3Bucket,
                'Key' => $s3Key,
            ]),
            '+1 hour'
        )->getUri()->__toString();
        
        // Prepare request to Deepgram
        $response = Http::withHeaders([
            'Authorization' => 'Token ' . $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'url' => $s3Url,
            'model' => 'nova-2',
            'language' => $this->mapLanguageCodeToDeepgram($language),
            'detect_language' => false,
            'diarize' => true,
            'numerals' => true,
            'punctuate' => true,
            'utterances' => true,
            'smart_format' => true,
            'multichannel' => false,
            'alternatives' => 1,
            'keywords' => [],
            'callback' => route('api.meeting.transcription.callback', ['meeting_id' => $meetingId])
        ]);
        
        if (!$response->successful()) {
            throw new \Exception('Failed to start transcription: ' . $response->body());
        }
        
        // Clean up local file
        @unlink($localPath);
        
        // Queue a job to check for completion in case callback fails
        dispatch(new \App\Jobs\CheckTranscriptionStatus($meetingId))
            ->delay(now()->addMinutes(5));
    }
    
    /**
     * Process transcription callback from Deepgram
     *
     * @param string $meetingId The meeting ID
     * @param array $transcriptionData The transcription data
     * @return void
     */
    public function processTranscriptionCallback(string $meetingId, array $transcriptionData): void
    {
        // Extract the full text
        $fullText = $transcriptionData['results']['channels'][0]['alternatives'][0]['transcript'] ?? '';
        
        // Extract speaker segments
        $segments = [];
        $paragraphs = $transcriptionData['results']['channels'][0]['alternatives'][0]['paragraphs']['paragraphs'] ?? [];
        
        foreach ($paragraphs as $paragraph) {
            $speaker = 'speaker_' . ($paragraph['speaker'] ?? 0);
            $text = $paragraph['text'] ?? '';
            $startTime = $paragraph['start'] ?? 0;
            
            if (!empty($text)) {
                $segments[] = [
                    'speaker' => $speaker,
                    'text' => $text,
                    'start_time' => $startTime,
                ];
            }
        }
        
        // Save to database
        $transcript = new Transcript();
        $transcript->meeting_id = $meetingId;
        $transcript->full_text = $fullText;
        $transcript->segments = $segments;
        $transcript->created_at = Carbon::now();
        $transcript->save();
        
        // Update meeting status
        $meeting = Meeting::where('meeting_id', $meetingId)->first();
        if ($meeting) {
            $meeting->status = 'transcribed';
            $meeting->duration = $transcriptionData['metadata']['duration'] ?? 0;
            $meeting->save();
        }
    }
    
    /**
     * Check the status of a transcription job
     *
     * @param string $meetingId The meeting ID
     * @return void
     */
    public function checkTranscriptionStatus(string $meetingId): void
    {
        // Check if transcript already exists
        $transcript = Transcript::where('meeting_id', $meetingId)->first();
        if ($transcript) {
            return; // Transcript already processed
        }
        
        // If no transcript exists after 5 minutes, use AssemblyAI as fallback
        $meeting = Meeting::where('meeting_id', $meetingId)->first();
        if (!$meeting) {
            Log::error("Meeting not found: {$meetingId}");
            return;
        }
        
        // Use AssemblyAI as fallback
        $apiKey = config('services.assemblyai.key');
        $endpoint = 'https://api.assemblyai.com/v2/transcript';
        
        // Prepare request
        $response = Http::withHeaders([
            'Authorization' => $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'audio_url' => $meeting->audio_url,
            'speaker_labels' => true,
            'language_code' => $this->mapLanguageCodeToAssemblyAI($meeting->language ?? 'en-US'),
        ]);
        
        if (!$response->successful()) {
            Log::error("Failed to start fallback transcription: " . $response->body());
            return;
        }
        
        $transcriptId = $response->json()['id'];
        
        // Poll for completion
        $complete = false;
        $maxAttempts = 30;
        $attempts = 0;
        
        while (!$complete && $attempts < $maxAttempts) {
            sleep(10); // Wait 10 seconds between polls
            
            $statusResponse = Http::withHeaders([
                'Authorization' => $apiKey,
            ])->get("{$endpoint}/{$transcriptId}");
            
            if (!$statusResponse->successful()) {
                Log::error("Failed to check transcription status: " . $statusResponse->body());
                $attempts++;
                continue;
            }
            
            $status = $statusResponse->json()['status'];
            
            if ($status === 'completed') {
                $complete = true;
                $this->processAssemblyAITranscript($meetingId, $statusResponse->json());
            } elseif ($status === 'error') {
                Log::error("Transcription failed: " . ($statusResponse->json()['error'] ?? 'Unknown error'));
                return;
            } else {
                $attempts++;
            }
        }
        
        if (!$complete) {
            Log::error("Transcription timed out for meeting: {$meetingId}");
            
            // Update meeting with error
            if ($meeting) {
                $meeting->status = 'failed';
                $meeting->save();
            }
        }
    }
    
    /**
     * Process AssemblyAI transcript
     *
     * @param string $meetingId The meeting ID
     * @param array $transcriptData The transcript data
     * @return void
     */
    private function processAssemblyAITranscript(string $meetingId, array $transcriptData): void
    {
        // Extract the full text
        $fullText = $transcriptData['text'] ?? '';
        
        // Extract speaker segments
        $segments = [];
        $utterances = $transcriptData['utterances'] ?? [];
        
        foreach ($utterances as $utterance) {
            $speaker = 'speaker_' . ($utterance['speaker'] ?? 0);
            $text = $utterance['text'] ?? '';
            $startTime = $utterance['start'] / 1000; // Convert from ms to seconds
            
            if (!empty($text)) {
                $segments[] = [
                    'speaker' => $speaker,
                    'text' => $text,
                    'start_time' => $startTime,
                ];
            }
        }
        
        // Save to database
        $transcript = new Transcript();
        $transcript->meeting_id = $meetingId;
        $transcript->full_text = $fullText;
        $transcript->segments = $segments;
        $transcript->created_at = Carbon::now();
        $transcript->save();
        
        // Update meeting status
        $meeting = Meeting::where('meeting_id', $meetingId)->first();
        if ($meeting) {
            $meeting->status = 'transcribed';
            $meeting->duration = ($transcriptData['audio_duration'] ?? 0) / 1000; // Convert from ms to seconds
            $meeting->save();
        }
    }
    
    /**
     * Generate a summary for a meeting
     *
     * @param string $text The meeting transcript text
     * @param string $language The language code
     * @return string The summary
     */
    public function generateSummary(string $text, string $language = 'en'): string
    {
        // Use Anthropic Claude via API
        $apiKey = config('services.anthropic.key');
        $endpoint = 'https://api.anthropic.com/v1/messages';
        
        $response = Http::withHeaders([
            'x-api-key' => $apiKey,
            'anthropic-version' => '2023-06-01',
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'model' => 'claude-3-haiku-20240307',
            'max_tokens' => 1000,
            'messages' => [
                [
                    'role' => 'user',
                    'content' => "You are a professional meeting summarizer. Create a concise summary of the following meeting transcript, highlighting key points, decisions, and outcomes. Use bullet points for clarity.\n\nTranscript:\n{$text}"
                ]
            ],
            'temperature' => 0.3,
        ]);
        
        if (!$response->successful()) {
            throw new \Exception('Summary generation failed: ' . $response->body());
        }
        
        $result = $response->json();
        return $result['content'][0]['text'] ?? '';
    }
    
    /**
     * Extract action items from a meeting transcript
     *
     * @param string $text The meeting transcript text
     * @param string $meetingId The meeting ID
     * @return array The action items
     */
    public function extractActionItems(string $text, string $meetingId): array
    {
        // Use Anthropic Claude via API
        $apiKey = config('services.anthropic.key');
        $endpoint = 'https://api.anthropic.com/v1/messages';
        
        $response = Http::withHeaders([
            'x-api-key' => $apiKey,
            'anthropic-version' => '2023-06-01',
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'model' => 'claude-3-haiku-20240307',
            'max_tokens' => 1000,
            'messages' => [
                [
                    'role' => 'user',
                    'content' => "You are an action item extractor. Identify all action items, tasks, and commitments from the meeting transcript. For each action item, extract: 1) The task description, 2) The assignee (who is responsible), 3) The due date if mentioned, and 4) The priority if mentioned. Return the results as a JSON array with the format: {\"action_items\": [{\"task\": \"...\", \"assignee\": \"...\", \"due_date\": \"...\", \"priority\": \"...\"}]}.\n\nTranscript:\n{$text}"
                ]
            ],
            'temperature' => 0.3,
        ]);
        
        if (!$response->successful()) {
            throw new \Exception('Action item extraction failed: ' . $response->body());
        }
        
        $result = $response->json();
        $content = $result['content'][0]['text'] ?? '';
        
        // Extract JSON from the response
        preg_match('/\{.*\}/s', $content, $matches);
        $jsonString = $matches[0] ?? '{"action_items":[]}';
        
        $actionData = json_decode($jsonString, true);
        $actionItems = $actionData['action_items'] ?? [];
        
        // Save action items to database
        foreach ($actionItems as $item) {
            $action = new Action();
            $action->meeting_id = $meetingId;
            $action->description = $item['task'] ?? '';
            $action->assignee = $item['assignee'] ?? '';
            $action->due_date = !empty($item['due_date']) ? Carbon::parse($item['due_date']) : null;
            $action->priority = $item['priority'] ?? 'medium';
            $action->status = 'pending';
            $action->created_at = Carbon::now();
            $action->save();
        }
        
        return $actionItems;
    }
    
    /**
     * Generate follow-up messages for action items
     *
     * @param \Illuminate\Database\Eloquent\Collection $actions The action items
     * @param Meeting $meeting The meeting
     * @return array The follow-up messages
     */
    public function generateFollowupMessages($actions, Meeting $meeting): array
    {
        $followups = [];
        $meetingTitle = $meeting->title;
        
        // Group actions by assignee
        $actionsByAssignee = [];
        foreach ($actions as $action) {
            $assignee = $action->assignee;
            if (!isset($actionsByAssignee[$assignee])) {
                $actionsByAssignee[$assignee] = [];
            }
            $actionsByAssignee[$assignee][] = $action;
        }
        
        // Generate follow-up for each assignee
        foreach ($actionsByAssignee as $assignee => $assigneeActions) {
            // Skip if no assignee
            if (empty($assignee)) {
                continue;
            }
            
            // Build action list
            $actionList = '';
            foreach ($assigneeActions as $index => $action) {
                $dueDate = $action->due_date ? $action->due_date->format('M j, Y') : 'Not specified';
                $actionList .= ($index + 1) . ". {$action->description} (Due: {$dueDate})\n";
            }
            
            // Generate email subject and body
            $subject = "Action Items from {$meetingTitle}";
            $body = "Hi {$assignee},\n\n";
            $body .= "Following up on our meeting \"{$meetingTitle}\", here are your action items:\n\n";
            $body .= $actionList . "\n";
            $body .= "Please let me know if you have any questions or need any clarification.\n\n";
            $body .= "Thanks,\n[Your Name]";
            
            $followups[] = [
                'assignee' => $assignee,
                'subject' => $subject,
                'body' => $body,
                'action_count' => count($assigneeActions),
            ];
        }
        
        return $followups;
    }
    
    /**
     * Download an audio file from a URL
     *
     * @param string $url The URL of the audio file
     * @return string The local path to the downloaded file
     */
    private function downloadAudioFile(string $url): string
    {
        $tempDir = storage_path('app/temp');
        if (!file_exists($tempDir)) {
            mkdir($tempDir, 0755, true);
        }
        
        $localPath = $tempDir . '/' . uniqid() . '.audio';
        
        $response = Http::withOptions([
            'sink' => $localPath,
        ])->get($url);
        
        if (!$response->successful()) {
            throw new \Exception('Failed to download audio file: ' . $response->status());
        }
        
        return $localPath;
    }
    
    /**
     * Map language code to Deepgram language code
     *
     * @param string $languageCode The language code
     * @return string The Deepgram language code
     */
    private function mapLanguageCodeToDeepgram(string $languageCode): string
    {
        $languageMap = [
            'en-US' => 'en-US',
            'en-GB' => 'en-GB',
            'fr-FR' => 'fr',
            'de-DE' => 'de',
            'es-ES' => 'es',
            'it-IT' => 'it',
            'ja-JP' => 'ja',
            'ko-KR' => 'ko',
            'pt-BR' => 'pt',
            'zh-CN' => 'zh-CN',
        ];
        
        return $languageMap[$languageCode] ?? 'en-US';
    }
    
    /**
     * Map language code to AssemblyAI language code
     *
     * @param string $languageCode The language code
     * @return string The AssemblyAI language code
     */
    private function mapLanguageCodeToAssemblyAI(string $languageCode): string
    {
        $languageMap = [
            'en-US' => 'en_us',
            'en-GB' => 'en_uk',
            'fr-FR' => 'fr',
            'de-DE' => 'de',
            'es-ES' => 'es',
            'it-IT' => 'it',
            'ja-JP' => 'ja',
            'ko-KR' => 'ko',
            'pt-BR' => 'pt',
            'zh-CN' => 'zh',
        ];
        
        return $languageMap[$languageCode] ?? 'en_us';
    }
    
    /**
     * Track the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return void
     */
    public function trackCost(string $operation, array $parameters): void
    {
        $cost = $this->calculateOperationCost($operation, $parameters);
        
        // Log the cost
        $costTracking = new OperationCost();
        $costTracking->operation = $operation;
        $costTracking->parameters = $parameters;
        $costTracking->cost = $cost;
        $costTracking->timestamp = Carbon::now();
        $costTracking->service = 'meeting-assistant';
        $costTracking->save();
        
        Log::info("Cost tracked for {$operation}: \${$cost}", $parameters);
    }
    
    /**
     * Calculate the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return float The cost in USD
     */
    private function calculateOperationCost(string $operation, array $parameters): float
    {
        switch ($operation) {
            case 'transcribe-meeting':
                // Deepgram: $0.0044 per minute of audio
                return 30 * 0.0044; // Estimate for 30 minutes
                
            case 'summarize-meeting':
                // Anthropic Claude: $0.015 per request (estimate)
                return 0.015;
                
            case 'extract-actions':
                // Anthropic Claude: $0.015 per request (estimate)
                return 0.015;
                
            case 'generate-followup':
                // $0.005 per action item
                $actionCount = $parameters['action_count'] ?? 1;
                return $actionCount * 0.005;
                
            default:
                return 0.0;
        }
    }
}
