<?php

namespace App\Services\AWS;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Models\CostTracking\OperationCost;
use Carbon\Carbon;

class CustomerJourneyService
{
    /**
     * Track a customer journey event
     *
     * @param string $userId The user ID
     * @param string $eventType The event type
     * @param array $eventData The event data
     * @return array The tracking result
     */
    public function trackEvent(string $userId, string $eventType, array $eventData): array
    {
        // Store event in database and S3
        $timestamp = Carbon::now();
        $eventId = uniqid('event_');
        
        // Prepare event record
        $event = [
            'event_id' => $eventId,
            'user_id' => $userId,
            'event_type' => $eventType,
            'event_data' => $eventData,
            'timestamp' => $timestamp->toIso8601String(),
            'session_id' => $eventData['session_id'] ?? null,
            'source' => $eventData['source'] ?? 'web',
            'ip_address' => $eventData['ip_address'] ?? null,
            'user_agent' => $eventData['user_agent'] ?? null,
        ];
        
        // Store in S3 for data lake
        $s3Key = "customer_journeys/{$userId}/{$eventType}/{$timestamp->format('Y/m/d')}/{$eventId}.json";
        $s3Bucket = config('services.aws.bucket');
        
        $s3 = app('aws')->createS3();
        $s3->putObject([
            'Bucket' => $s3Bucket,
            'Key' => $s3Key,
            'Body' => json_encode($event),
            'ContentType' => 'application/json',
        ]);
        
        // Track cost
        $this->trackCost('track-event', [
            'event_type' => $eventType,
            'data_size' => strlen(json_encode($event)),
        ]);
        
        return [
            'event_id' => $eventId,
            'timestamp' => $timestamp->toIso8601String(),
            'status' => 'recorded',
        ];
    }
    
    /**
     * Analyze a user's journey
     *
     * @param string $userId The user ID
     * @param string $startDate The start date (ISO format)
     * @param string $endDate The end date (ISO format)
     * @return array The analysis result
     */
    public function analyzeUserJourney(string $userId, string $startDate = null, string $endDate = null): array
    {
        // Set default date range if not provided
        if (!$startDate) {
            $startDate = Carbon::now()->subDays(30)->startOfDay()->toIso8601String();
        }
        
        if (!$endDate) {
            $endDate = Carbon::now()->endOfDay()->toIso8601String();
        }
        
        // Fetch events from S3
        $events = $this->fetchUserEvents($userId, $startDate, $endDate);
        
        // Use Mixpanel for journey analysis
        $apiKey = config('services.mixpanel.key');
        $projectId = config('services.mixpanel.project_id');
        $endpoint = "https://mixpanel.com/api/2.0/engage?project_id={$projectId}";
        
        // Prepare request
        $response = Http::withBasicAuth($apiKey, '')->get($endpoint, [
            'where' => json_encode(['$properties' => ['user_id' => $userId]]),
        ]);
        
        if (!$response->successful()) {
            // Fallback to local analysis if Mixpanel fails
            return $this->performLocalJourneyAnalysis($events);
        }
        
        $mixpanelData = $response->json();
        
        // Combine Mixpanel data with our events
        $analysis = $this->combineAnalysisData($events, $mixpanelData);
        
        // Track cost
        $this->trackCost('analyze-journey', [
            'user_id' => $userId,
            'event_count' => count($events),
        ]);
        
        return $analysis;
    }
    
    /**
     * Generate recommendations for a user
     *
     * @param string $userId The user ID
     * @param array $userProfile The user profile data
     * @param array $recentEvents Recent user events
     * @return array The recommendations
     */
    public function generateRecommendations(string $userId, array $userProfile, array $recentEvents): array
    {
        // Use OpenAI API for personalized recommendations
        $apiKey = config('services.openai.key');
        $endpoint = 'https://api.openai.com/v1/chat/completions';
        
        // Prepare context for the AI
        $context = [
            'user_id' => $userId,
            'profile' => $userProfile,
            'recent_events' => array_slice($recentEvents, 0, 10), // Limit to 10 most recent events
        ];
        
        // Prepare request
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are a customer journey optimization expert. Based on the user profile and recent events, generate personalized recommendations to improve their experience and engagement.'
                ],
                [
                    'role' => 'user',
                    'content' => 'Generate 3-5 personalized recommendations based on this user data: ' . json_encode($context)
                ]
            ],
            'temperature' => 0.7,
            'max_tokens' => 500,
        ]);
        
        if (!$response->successful()) {
            // Fallback to rule-based recommendations
            return $this->generateRuleBasedRecommendations($userProfile, $recentEvents);
        }
        
        $aiResponse = $response->json();
        $recommendationsText = $aiResponse['choices'][0]['message']['content'] ?? '';
        
        // Parse recommendations from AI response
        $recommendations = $this->parseRecommendationsFromText($recommendationsText);
        
        // Track cost
        $this->trackCost('generate-recommendations', [
            'user_id' => $userId,
            'recommendation_count' => count($recommendations),
        ]);
        
        return [
            'user_id' => $userId,
            'recommendations' => $recommendations,
            'generated_at' => Carbon::now()->toIso8601String(),
        ];
    }
    
    /**
     * Optimize a specific touchpoint
     *
     * @param string $touchpointId The touchpoint ID
     * @param array $touchpointData The touchpoint data
     * @param array $performanceMetrics Performance metrics
     * @return array The optimization result
     */
    public function optimizeTouchpoint(string $touchpointId, array $touchpointData, array $performanceMetrics): array
    {
        // Use OpenAI API for touchpoint optimization
        $apiKey = config('services.openai.key');
        $endpoint = 'https://api.openai.com/v1/chat/completions';
        
        // Prepare context for the AI
        $context = [
            'touchpoint_id' => $touchpointId,
            'touchpoint_data' => $touchpointData,
            'performance_metrics' => $performanceMetrics,
        ];
        
        // Prepare request
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are a customer experience optimization expert. Based on the touchpoint data and performance metrics, suggest specific improvements to optimize this customer touchpoint.'
                ],
                [
                    'role' => 'user',
                    'content' => 'Suggest specific optimizations for this touchpoint: ' . json_encode($context)
                ]
            ],
            'temperature' => 0.7,
            'max_tokens' => 500,
        ]);
        
        if (!$response->successful()) {
            // Fallback to rule-based optimization
            return $this->generateRuleBasedOptimization($touchpointData, $performanceMetrics);
        }
        
        $aiResponse = $response->json();
        $optimizationText = $aiResponse['choices'][0]['message']['content'] ?? '';
        
        // Parse optimization suggestions from AI response
        $optimizations = $this->parseOptimizationsFromText($optimizationText);
        
        // Track cost
        $this->trackCost('optimize-touchpoint', [
            'touchpoint_id' => $touchpointId,
            'optimization_count' => count($optimizations),
        ]);
        
        return [
            'touchpoint_id' => $touchpointId,
            'optimizations' => $optimizations,
            'generated_at' => Carbon::now()->toIso8601String(),
        ];
    }
    
    /**
     * Fetch user events from S3
     *
     * @param string $userId The user ID
     * @param string $startDate The start date (ISO format)
     * @param string $endDate The end date (ISO format)
     * @return array The user events
     */
    private function fetchUserEvents(string $userId, string $startDate, string $endDate): array
    {
        $s3 = app('aws')->createS3();
        $s3Bucket = config('services.aws.bucket');
        
        // List objects in the user's directory
        $objects = $s3->listObjectsV2([
            'Bucket' => $s3Bucket,
            'Prefix' => "customer_journeys/{$userId}/",
        ]);
        
        $events = [];
        $startDateTime = new Carbon($startDate);
        $endDateTime = new Carbon($endDate);
        
        // Filter and fetch events within date range
        foreach ($objects['Contents'] ?? [] as $object) {
            $key = $object['Key'];
            
            // Extract date from key
            if (preg_match('/(\d{4})\/(\d{2})\/(\d{2})/', $key, $matches)) {
                $year = $matches[1];
                $month = $matches[2];
                $day = $matches[3];
                
                $objectDate = Carbon::createFromDate($year, $month, $day);
                
                if ($objectDate->between($startDateTime, $endDateTime)) {
                    $result = $s3->getObject([
                        'Bucket' => $s3Bucket,
                        'Key' => $key,
                    ]);
                    
                    $event = json_decode($result['Body'], true);
                    if ($event) {
                        $events[] = $event;
                    }
                }
            }
        }
        
        // Sort events by timestamp
        usort($events, function($a, $b) {
            return strcmp($a['timestamp'], $b['timestamp']);
        });
        
        return $events;
    }
    
    /**
     * Perform local journey analysis
     *
     * @param array $events The user events
     * @return array The analysis result
     */
    private function performLocalJourneyAnalysis(array $events): array
    {
        // Group events by type
        $eventsByType = [];
        foreach ($events as $event) {
            $type = $event['event_type'];
            if (!isset($eventsByType[$type])) {
                $eventsByType[$type] = [];
            }
            $eventsByType[$type][] = $event;
        }
        
        // Calculate basic metrics
        $metrics = [
            'total_events' => count($events),
            'event_types' => count($eventsByType),
            'first_event' => $events[0]['timestamp'] ?? null,
            'last_event' => $events[count($events) - 1]['timestamp'] ?? null,
        ];
        
        // Identify common paths
        $paths = $this->identifyCommonPaths($events);
        
        // Identify potential drop-off points
        $dropoffs = $this->identifyDropoffPoints($events);
        
        return [
            'metrics' => $metrics,
            'event_distribution' => array_map('count', $eventsByType),
            'common_paths' => $paths,
            'potential_dropoffs' => $dropoffs,
        ];
    }
    
    /**
     * Combine analysis data from multiple sources
     *
     * @param array $events The user events
     * @param array $mixpanelData The Mixpanel data
     * @return array The combined analysis
     */
    private function combineAnalysisData(array $events, array $mixpanelData): array
    {
        // Extract relevant data from Mixpanel
        $mixpanelProfile = $mixpanelData['results'][0] ?? [];
        $mixpanelProperties = $mixpanelProfile['$properties'] ?? [];
        
        // Perform local analysis
        $localAnalysis = $this->performLocalJourneyAnalysis($events);
        
        // Combine with Mixpanel insights
        return array_merge($localAnalysis, [
            'user_profile' => [
                'first_seen' => $mixpanelProperties['$first_seen'] ?? null,
                'last_seen' => $mixpanelProperties['$last_seen'] ?? null,
                'total_sessions' => $mixpanelProperties['$sessions'] ?? 0,
                'engagement_score' => $mixpanelProperties['engagement_score'] ?? 0,
            ],
        ]);
    }
    
    /**
     * Generate rule-based recommendations
     *
     * @param array $userProfile The user profile
     * @param array $recentEvents Recent user events
     * @return array The recommendations
     */
    private function generateRuleBasedRecommendations(array $userProfile, array $recentEvents): array
    {
        $recommendations = [];
        
        // Check for abandoned cart
        $hasAbandonedCart = false;
        foreach ($recentEvents as $event) {
            if ($event['event_type'] === 'add_to_cart') {
                $hasAbandonedCart = true;
            }
            if ($event['event_type'] === 'purchase') {
                $hasAbandonedCart = false;
                break;
            }
        }
        
        if ($hasAbandonedCart) {
            $recommendations[] = [
                'type' => 'abandoned_cart',
                'title' => 'Complete Your Purchase',
                'description' => 'You have items waiting in your cart. Complete your purchase to enjoy your selected products.',
                'priority' => 'high',
            ];
        }
        
        // Check for inactive user
        $lastActivity = null;
        foreach ($recentEvents as $event) {
            $eventTime = new Carbon($event['timestamp']);
            if (!$lastActivity || $eventTime->gt($lastActivity)) {
                $lastActivity = $eventTime;
            }
        }
        
        if ($lastActivity && $lastActivity->lt(Carbon::now()->subDays(14))) {
            $recommendations[] = [
                'type' => 'reengagement',
                'title' => 'We Miss You!',
                'description' => 'It\'s been a while since your last visit. Check out our latest features and updates.',
                'priority' => 'medium',
            ];
        }
        
        // Add generic recommendations
        $recommendations[] = [
            'type' => 'feature_discovery',
            'title' => 'Discover New Features',
            'description' => 'Explore our latest features to get the most out of your experience.',
            'priority' => 'low',
        ];
        
        return $recommendations;
    }
    
    /**
     * Generate rule-based touchpoint optimization
     *
     * @param array $touchpointData The touchpoint data
     * @param array $performanceMetrics Performance metrics
     * @return array The optimization suggestions
     */
    private function generateRuleBasedOptimization(array $touchpointData, array $performanceMetrics): array
    {
        $optimizations = [];
        
        // Check conversion rate
        if (isset($performanceMetrics['conversion_rate']) && $performanceMetrics['conversion_rate'] < 0.02) {
            $optimizations[] = [
                'type' => 'conversion',
                'title' => 'Improve Call-to-Action',
                'description' => 'The conversion rate is below average. Consider making the call-to-action more prominent and compelling.',
                'priority' => 'high',
            ];
        }
        
        // Check bounce rate
        if (isset($performanceMetrics['bounce_rate']) && $performanceMetrics['bounce_rate'] > 0.7) {
            $optimizations[] = [
                'type' => 'engagement',
                'title' => 'Reduce Bounce Rate',
                'description' => 'The bounce rate is high. Consider improving the initial content to better engage users.',
                'priority' => 'high',
            ];
        }
        
        // Check load time
        if (isset($performanceMetrics['load_time']) && $performanceMetrics['load_time'] > 3.0) {
            $optimizations[] = [
                'type' => 'performance',
                'title' => 'Improve Load Time',
                'description' => 'The page load time is slow. Optimize images and scripts to improve performance.',
                'priority' => 'medium',
            ];
        }
        
        // Add generic optimization
        $optimizations[] = [
            'type' => 'content',
            'title' => 'Enhance Content Quality',
            'description' => 'Regularly update content to keep it fresh and relevant to your audience.',
            'priority' => 'low',
        ];
        
        return $optimizations;
    }
    
    /**
     * Identify common paths from events
     *
     * @param array $events The user events
     * @return array The common paths
     */
    private function identifyCommonPaths(array $events): array
    {
        // Extract event sequence
        $sequence = [];
        foreach ($events as $event) {
            $sequence[] = $event['event_type'];
        }
        
        // Find common subsequences (simplified)
        $paths = [];
        $windowSize = 3; // Look for paths of 3 consecutive events
        
        for ($i = 0; $i <= count($sequence) - $windowSize; $i++) {
            $path = array_slice($sequence, $i, $windowSize);
            $pathStr = implode(' > ', $path);
            
            if (!isset($paths[$pathStr])) {
                $paths[$pathStr] = 0;
            }
            
            $paths[$pathStr]++;
        }
        
        // Sort by frequency
        arsort($paths);
        
        // Format result
        $result = [];
        foreach (array_slice($paths, 0, 5) as $path => $count) {
            $result[] = [
                'path' => $path,
                'count' => $count,
            ];
        }
        
        return $result;
    }
    
    /**
     * Identify potential drop-off points
     *
     * @param array $events The user events
     * @return array The drop-off points
     */
    private function identifyDropoffPoints(array $events): array
    {
        // Group events by session
        $sessions = [];
        foreach ($events as $event) {
            $sessionId = $event['session_id'] ?? 'unknown';
            if (!isset($sessions[$sessionId])) {
                $sessions[$sessionId] = [];
            }
            $sessions[$sessionId][] = $event;
        }
        
        // Find last event of each session
        $lastEvents = [];
        foreach ($sessions as $sessionId => $sessionEvents) {
            usort($sessionEvents, function($a, $b) {
                return strcmp($a['timestamp'], $b['timestamp']);
            });
            
            $lastEvent = end($sessionEvents);
            $lastEventType = $lastEvent['event_type'];
            
            if (!isset($lastEvents[$lastEventType])) {
                $lastEvents[$lastEventType] = 0;
            }
            
            $lastEvents[$lastEventType]++;
        }
        
        // Sort by frequency
        arsort($lastEvents);
        
        // Format result
        $result = [];
        foreach (array_slice($lastEvents, 0, 5) as $eventType => $count) {
            $result[] = [
                'event_type' => $eventType,
                'count' => $count,
                'percentage' => round(($count / count($sessions)) * 100, 2),
            ];
        }
        
        return $result;
    }
    
    /**
     * Parse recommendations from AI-generated text
     *
     * @param string $text The AI-generated text
     * @return array The parsed recommendations
     */
    private function parseRecommendationsFromText(string $text): array
    {
        $recommendations = [];
        
        // Simple parsing based on numbered lists or bullet points
        $lines = explode("\n", $text);
        $currentRec = null;
        
        foreach ($lines as $line) {
            $line = trim($line);
            
            // Check for numbered recommendation or bullet point
            if (preg_match('/^(\d+\.|\*|\-)\s+(.+)$/', $line, $matches)) {
                if ($currentRec) {
                    $recommendations[] = $currentRec;
                }
                
                $currentRec = [
                    'title' => $matches[2],
                    'description' => '',
                    'priority' => 'medium',
                ];
            } 
            // If not a new recommendation, add to description of current one
            elseif ($currentRec && !empty($line)) {
                if (!empty($currentRec['description'])) {
                    $currentRec['description'] .= ' ';
                }
                $currentRec['description'] .= $line;
            }
        }
        
        // Add the last recommendation if exists
        if ($currentRec) {
            $recommendations[] = $currentRec;
        }
        
        // If no recommendations were parsed, create a generic one from the text
        if (empty($recommendations) && !empty($text)) {
            $recommendations[] = [
                'title' => 'Personalized Recommendation',
                'description' => substr($text, 0, 200) . (strlen($text) > 200 ? '...' : ''),
                'priority' => 'medium',
            ];
        }
        
        return $recommendations;
    }
    
    /**
     * Parse optimizations from AI-generated text
     *
     * @param string $text The AI-generated text
     * @return array The parsed optimizations
     */
    private function parseOptimizationsFromText(string $text): array
    {
        // Use the same parsing logic as recommendations
        return $this->parseRecommendationsFromText($text);
    }
    
    /**
     * Track the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return void
     */
    public function trackCost(string $operation, array $parameters): void
    {
        $cost = $this->calculateOperationCost($operation, $parameters);
        
        // Log the cost
        $costTracking = new OperationCost();
        $costTracking->operation = $operation;
        $costTracking->parameters = $parameters;
        $costTracking->cost = $cost;
        $costTracking->timestamp = Carbon::now();
        $costTracking->service = 'customer-journey';
        $costTracking->save();
        
        Log::info("Cost tracked for {$operation}: \${$cost}", $parameters);
    }
    
    /**
     * Calculate the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return float The cost in USD
     */
    private function calculateOperationCost(string $operation, array $parameters): float
    {
        switch ($operation) {
            case 'track-event':
                // S3 storage: $0.023 per GB, but negligible for small events
                // Estimate $0.0001 per event for storage and processing
                return 0.0001;
                
            case 'analyze-journey':
                // Mixpanel: Included in subscription, estimate $0.01 per analysis
                return 0.01;
                
            case 'generate-recommendations':
                // OpenAI GPT-3.5: $0.0015 per 1K tokens, estimate 1K tokens per recommendation
                $count = $parameters['recommendation_count'] ?? 3;
                return 0.0015 * $count;
                
            case 'optimize-touchpoint':
                // OpenAI GPT-3.5: $0.0015 per 1K tokens, estimate 1K tokens per optimization
                $count = $parameters['optimization_count'] ?? 3;
                return 0.0015 * $count;
                
            default:
                return 0.0;
        }
    }
}
