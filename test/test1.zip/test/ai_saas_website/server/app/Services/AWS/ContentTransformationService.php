<?php

namespace App\Services\AWS;

use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use App\Models\CostTracking\OperationCost;
use Carbon\Carbon;

class ContentTransformationService
{
    /**
     * Transform text to speech using Replicate
     *
     * @param string $text The text to transform
     * @param string $voice The voice to use
     * @param string $format The output format (mp3, ogg, pcm)
     * @param float $speed The speech speed
     * @return array The transformation result
     */
    public function transformTextToSpeech(string $text, string $voice = 'default', string $format = 'mp3', float $speed = 1.0): array
    {
        // Use ElevenLabs API for text-to-speech
        $apiKey = config('services.elevenlabs.key');
        $endpoint = 'https://api.elevenlabs.io/v1/text-to-speech';
        
        // Map voice parameter to ElevenLabs voice ID
        $voiceId = $this->mapVoiceToElevenLabsVoice($voice);
        
        // Prepare request
        $response = Http::withHeaders([
            'xi-api-key' => $apiKey,
            'Content-Type' => 'application/json',
        ])->post("{$endpoint}/{$voiceId}", [
            'text' => $text,
            'model_id' => 'eleven_multilingual_v2',
            'voice_settings' => [
                'stability' => 0.5,
                'similarity_boost' => 0.75,
                'style' => 0.0,
                'use_speaker_boost' => true,
                'speed' => $speed
            ]
        ]);
        
        if (!$response->successful()) {
            throw new \Exception('Text-to-speech transformation failed: ' . $response->body());
        }
        
        // Save the audio stream to storage
        $audioData = $response->body();
        $fileName = 'speech_' . uniqid() . '.mp3';
        $path = 'audio_outputs/' . $fileName;
        
        Storage::put($path, $audioData);
        
        // Generate public URL
        $audioUrl = Storage::url($path);
        
        // Calculate duration (approximate)
        $duration = $this->calculateAudioDuration($text, $speed);
        
        return [
            'audio_url' => $audioUrl,
            'duration' => $duration,
            'format' => 'mp3',
        ];
    }
    
    /**
     * Transform speech to text using Replicate
     *
     * @param string $audioPath Path to the audio file
     * @param string $language Language code
     * @return array The transformation result
     */
    public function transformSpeechToText(string $audioPath, string $language = 'en-US'): array
    {
        // Use Whisper API via Replicate
        $apiKey = config('services.replicate.key');
        $endpoint = 'https://api.replicate.com/v1/predictions';
        
        // Read file as base64
        $audioData = base64_encode(file_get_contents($audioPath));
        
        // Prepare request
        $response = Http::withHeaders([
            'Authorization' => 'Token ' . $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'version' => 'a16e0b08f2f22a901d4c2d6f5b05539a5b3dc37454e7031dd0f9ec5a3b8b8bcd',
            'input' => [
                'audio' => "data:audio/mp3;base64,{$audioData}",
                'language' => $this->mapLanguageCodeToWhisper($language),
                'transcription' => 'plain text',
                'translate' => false,
                'temperature' => 0,
                'suppress_tokens' => '-1',
                'condition_on_previous_text' => false,
                'temperature_increment_on_fallback' => 0.2,
                'compression_ratio_threshold' => 2.4,
                'logprob_threshold' => -1,
                'no_speech_threshold' => 0.6
            ]
        ]);
        
        if (!$response->successful()) {
            throw new \Exception('Speech-to-text transformation failed: ' . $response->body());
        }
        
        $predictionId = $response->json()['id'];
        
        // Poll for completion
        $complete = false;
        $maxAttempts = 30;
        $attempts = 0;
        $result = null;
        
        while (!$complete && $attempts < $maxAttempts) {
            $statusResponse = Http::withHeaders([
                'Authorization' => 'Token ' . $apiKey,
            ])->get("{$endpoint}/{$predictionId}");
            
            if (!$statusResponse->successful()) {
                throw new \Exception('Failed to check prediction status: ' . $statusResponse->body());
            }
            
            $status = $statusResponse->json()['status'];
            
            if ($status === 'succeeded') {
                $complete = true;
                $result = $statusResponse->json()['output'];
            } elseif ($status === 'failed') {
                throw new \Exception('Transcription job failed: ' . 
                    ($statusResponse->json()['error'] ?? 'Unknown reason'));
            } else {
                // Wait before polling again
                sleep(2);
                $attempts++;
            }
        }
        
        if (!$complete) {
            throw new \Exception('Transcription timed out');
        }
        
        // Calculate audio duration (approximate)
        $audioDuration = $this->getAudioDuration($audioPath);
        
        return [
            'text' => $result['text'] ?? '',
            'confidence' => 0.9, // Whisper doesn't provide confidence scores
            'language' => $language,
            'duration' => $audioDuration,
        ];
    }
    
    /**
     * Transform text to image using Replicate
     *
     * @param string $text The text to transform
     * @param string $style The image style
     * @param string $size The image size
     * @return array The transformation result
     */
    public function transformTextToImage(string $text, string $style = 'default', string $size = '512x512'): array
    {
        // Use Stable Diffusion via Replicate
        $apiKey = config('services.replicate.key');
        $endpoint = 'https://api.replicate.com/v1/predictions';
        
        // Parse size
        list($width, $height) = explode('x', $size);
        
        // Map style to a prompt suffix
        $styleSuffix = $this->mapStyleToPromptSuffix($style);
        $fullPrompt = $text . ($style !== 'default' ? ", {$styleSuffix}" : "");
        
        // Prepare request
        $response = Http::withHeaders([
            'Authorization' => 'Token ' . $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'version' => 'db21e45d3f7023abc2a46ee38a23973f6dce16bb082a930b0c49861f96d1e5bf',
            'input' => [
                'prompt' => $fullPrompt,
                'negative_prompt' => 'blurry, bad quality, distorted, disfigured',
                'width' => (int)$width,
                'height' => (int)$height,
                'num_outputs' => 1,
                'guidance_scale' => 7.5,
                'scheduler' => 'DPMSolverMultistep',
                'num_inference_steps' => 25
            ]
        ]);
        
        if (!$response->successful()) {
            throw new \Exception('Text-to-image transformation failed: ' . $response->body());
        }
        
        $predictionId = $response->json()['id'];
        
        // Poll for completion
        $complete = false;
        $maxAttempts = 30;
        $attempts = 0;
        $result = null;
        
        while (!$complete && $attempts < $maxAttempts) {
            $statusResponse = Http::withHeaders([
                'Authorization' => 'Token ' . $apiKey,
            ])->get("{$endpoint}/{$predictionId}");
            
            if (!$statusResponse->successful()) {
                throw new \Exception('Failed to check prediction status: ' . $statusResponse->body());
            }
            
            $status = $statusResponse->json()['status'];
            
            if ($status === 'succeeded') {
                $complete = true;
                $result = $statusResponse->json()['output'];
            } elseif ($status === 'failed') {
                throw new \Exception('Image generation failed: ' . 
                    ($statusResponse->json()['error'] ?? 'Unknown reason'));
            } else {
                // Wait before polling again
                sleep(2);
                $attempts++;
            }
        }
        
        if (!$complete) {
            throw new \Exception('Image generation timed out');
        }
        
        // Download the image and save to storage
        $imageUrl = $result[0] ?? null;
        if (!$imageUrl) {
            throw new \Exception('No image URL in the response');
        }
        
        $imageResponse = Http::get($imageUrl);
        if (!$imageResponse->successful()) {
            throw new \Exception('Failed to download generated image');
        }
        
        $imageData = $imageResponse->body();
        $fileName = 'image_' . uniqid() . '.png';
        $path = 'image_outputs/' . $fileName;
        
        Storage::put($path, $imageData);
        
        // Generate public URL
        $storedImageUrl = Storage::url($path);
        
        return [
            'image_url' => $storedImageUrl,
            'size' => $size,
            'format' => 'png',
        ];
    }
    
    /**
     * Track the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return void
     */
    public function trackCost(string $operation, array $parameters): void
    {
        $cost = $this->calculateOperationCost($operation, $parameters);
        
        // Log the cost
        $costTracking = new OperationCost();
        $costTracking->operation = $operation;
        $costTracking->parameters = $parameters;
        $costTracking->cost = $cost;
        $costTracking->timestamp = Carbon::now();
        $costTracking->service = 'content-transformation';
        $costTracking->save();
        
        Log::info("Cost tracked for {$operation}: \${$cost}", $parameters);
    }
    
    /**
     * Calculate the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return float The cost in USD
     */
    private function calculateOperationCost(string $operation, array $parameters): float
    {
        switch ($operation) {
            case 'text-to-speech':
                // ElevenLabs: $0.006 per 1000 characters
                $textLength = $parameters['text_length'] ?? 0;
                return ($textLength / 1000) * 0.006;
                
            case 'speech-to-text':
                // Whisper via Replicate: $0.0005 per second of audio
                $audioDuration = $parameters['audio_duration'] ?? 0;
                return $audioDuration * 0.0005;
                
            case 'text-to-image':
                // Stable Diffusion via Replicate: $0.002 per image
                return 0.002;
                
            default:
                return 0.0;
        }
    }
    
    /**
     * Map voice name to ElevenLabs voice ID
     *
     * @param string $voice The voice name
     * @return string The ElevenLabs voice ID
     */
    private function mapVoiceToElevenLabsVoice(string $voice): string
    {
        $voiceMap = [
            'default' => '21m00Tcm4TlvDq8ikWAM', // Adam
            'male' => '21m00Tcm4TlvDq8ikWAM',    // Adam
            'female' => 'EXAVITQu4vr4xnSDxMaL',  // Rachel
            'child' => 'flq6f7yk4E4fJM5XTYuZ',   // Freya
            'british_male' => 'pNInz6obpgDQGcFmaJgB', // Harry
            'british_female' => 'jsCqWAovK2LkecY7zXl4', // Bella
            'american_male' => '21m00Tcm4TlvDq8ikWAM', // Adam
            'american_female' => 'EXAVITQu4vr4xnSDxMaL', // Rachel
        ];
        
        return $voiceMap[$voice] ?? '21m00Tcm4TlvDq8ikWAM'; // Default to Adam
    }
    
    /**
     * Map language code to Whisper language code
     *
     * @param string $languageCode The language code
     * @return string The Whisper language code
     */
    private function mapLanguageCodeToWhisper(string $languageCode): string
    {
        $languageMap = [
            'en-US' => 'en',
            'en-GB' => 'en',
            'fr-FR' => 'fr',
            'de-DE' => 'de',
            'es-ES' => 'es',
            'it-IT' => 'it',
            'ja-JP' => 'ja',
            'ko-KR' => 'ko',
            'pt-BR' => 'pt',
            'zh-CN' => 'zh',
        ];
        
        return $languageMap[$languageCode] ?? 'en';
    }
    
    /**
     * Map style to prompt suffix for Stable Diffusion
     *
     * @param string $style The style name
     * @return string The prompt suffix
     */
    private function mapStyleToPromptSuffix(string $style): string
    {
        $styleMap = [
            'default' => '',
            'photographic' => 'photorealistic, high detail, 8k, professional photography',
            'digital_art' => 'digital art, vibrant colors, detailed, artstation',
            'anime' => 'anime style, manga, vibrant, detailed, studio ghibli',
            'painting' => 'oil painting, detailed brushwork, artistic, museum quality',
            'sketch' => 'pencil sketch, detailed, hand-drawn, black and white',
            'watercolor' => 'watercolor painting, soft colors, flowing, artistic',
            'pixel_art' => 'pixel art, 8-bit, retro game style',
            'fantasy' => 'fantasy art, magical, ethereal, detailed, vibrant',
            'sci_fi' => 'sci-fi, futuristic, technological, detailed, cinematic',
        ];
        
        return $styleMap[$style] ?? '';
    }
    
    /**
     * Calculate approximate audio duration based on text length and speed
     *
     * @param string $text The text
     * @param float $speed The speech speed
     * @return float The duration in seconds
     */
    private function calculateAudioDuration(string $text, float $speed): float
    {
        // Average speaking rate is about 150 words per minute
        $wordCount = str_word_count($text);
        $minutesAtNormalSpeed = $wordCount / 150;
        $seconds = $minutesAtNormalSpeed * 60;
        
        // Adjust for speed
        return $seconds / $speed;
    }
    
    /**
     * Get audio duration using ffprobe
     *
     * @param string $audioPath The path to the audio file
     * @return float The duration in seconds
     */
    private function getAudioDuration(string $audioPath): float
    {
        try {
            $command = "ffprobe -i {$audioPath} -show_entries format=duration -v quiet -of csv=\"p=0\"";
            $duration = trim(shell_exec($command));
            return floatval($duration);
        } catch (\Exception $e) {
            // Fallback to approximation based on file size
            $fileSize = filesize($audioPath);
            // Rough estimate: 16kbps MP3 = 2KB per second
            return $fileSize / 2000;
        }
    }
}
