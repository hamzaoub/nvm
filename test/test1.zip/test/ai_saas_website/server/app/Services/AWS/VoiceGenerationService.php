<?php

namespace App\Services\AWS;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use App\Models\CostTracking\OperationCost;
use Carbon\Carbon;

class VoiceGenerationService
{
    /**
     * Create a voice profile
     *
     * @param string $name The name of the voice profile
     * @param string $audioUrl The URL of the audio sample
     * @param string $description The description of the voice
     * @param string $gender The gender of the voice
     * @return array The voice profile data
     */
    public function createVoiceProfile(string $name, string $audioUrl, string $description = '', string $gender = 'neutral'): array
    {
        // Use ElevenLabs API for voice cloning
        $apiKey = config('services.elevenlabs.key');
        $endpoint = 'https://api.elevenlabs.io/v1/voices/add';
        
        // Download the audio file
        $localPath = $this->downloadAudioFile($audioUrl);
        
        // Prepare multipart request
        $response = Http::withHeaders([
            'xi-api-key' => $apiKey,
        ])->attach(
            'files', file_get_contents($localPath), basename($localPath)
        )->post($endpoint, [
            'name' => $name,
            'description' => $description,
            'labels' => json_encode(['gender' => $gender])
        ]);
        
        // Clean up local file
        @unlink($localPath);
        
        if (!$response->successful()) {
            throw new \Exception('Voice profile creation failed: ' . $response->body());
        }
        
        $voiceData = $response->json();
        
        // Track cost
        $this->trackCost('create-voice-profile', [
            'name' => $name,
            'audio_duration' => 60, // Estimate 60 seconds of audio
        ]);
        
        return [
            'voice_id' => $voiceData['voice_id'],
            'name' => $voiceData['name'],
            'description' => $voiceData['description'] ?? $description,
            'gender' => $gender,
            'created_at' => Carbon::now()->toIso8601String(),
        ];
    }
    
    /**
     * Generate speech using a voice profile
     *
     * @param string $voiceId The voice profile ID
     * @param string $text The text to convert to speech
     * @param float $stability The stability of the voice (0.0-1.0)
     * @param float $similarity The similarity to the original voice (0.0-1.0)
     * @param float $speed The speech speed
     * @return array The generated speech data
     */
    public function generateSpeech(string $voiceId, string $text, float $stability = 0.5, float $similarity = 0.75, float $speed = 1.0): array
    {
        // Use ElevenLabs API for text-to-speech
        $apiKey = config('services.elevenlabs.key');
        $endpoint = "https://api.elevenlabs.io/v1/text-to-speech/{$voiceId}";
        
        // Prepare request
        $response = Http::withHeaders([
            'xi-api-key' => $apiKey,
            'Content-Type' => 'application/json',
        ])->post($endpoint, [
            'text' => $text,
            'model_id' => 'eleven_multilingual_v2',
            'voice_settings' => [
                'stability' => $stability,
                'similarity_boost' => $similarity,
                'style' => 0.0,
                'use_speaker_boost' => true,
                'speed' => $speed
            ]
        ]);
        
        if (!$response->successful()) {
            throw new \Exception('Speech generation failed: ' . $response->body());
        }
        
        // Save the audio stream to storage
        $audioData = $response->body();
        $fileName = 'speech_' . uniqid() . '.mp3';
        $path = 'audio_outputs/' . $fileName;
        
        Storage::put($path, $audioData);
        
        // Generate public URL
        $audioUrl = Storage::url($path);
        
        // Calculate duration (approximate)
        $duration = $this->calculateAudioDuration($text, $speed);
        
        // Track cost
        $this->trackCost('generate-speech', [
            'text_length' => strlen($text),
            'duration' => $duration,
        ]);
        
        return [
            'audio_url' => $audioUrl,
            'duration' => $duration,
            'format' => 'mp3',
            'voice_id' => $voiceId,
        ];
    }
    
    /**
     * List available voice profiles
     *
     * @return array The list of voice profiles
     */
    public function listVoiceProfiles(): array
    {
        // Use ElevenLabs API to list voices
        $apiKey = config('services.elevenlabs.key');
        $endpoint = 'https://api.elevenlabs.io/v1/voices';
        
        $response = Http::withHeaders([
            'xi-api-key' => $apiKey,
        ])->get($endpoint);
        
        if (!$response->successful()) {
            throw new \Exception('Failed to list voice profiles: ' . $response->body());
        }
        
        $voicesData = $response->json();
        $voices = [];
        
        foreach ($voicesData['voices'] ?? [] as $voice) {
            $voices[] = [
                'voice_id' => $voice['voice_id'],
                'name' => $voice['name'],
                'description' => $voice['description'] ?? '',
                'gender' => $this->extractGenderFromLabels($voice['labels'] ?? []),
                'preview_url' => $voice['preview_url'] ?? null,
                'created_at' => $voice['created_at'] ?? null,
            ];
        }
        
        return $voices;
    }
    
    /**
     * Delete a voice profile
     *
     * @param string $voiceId The voice profile ID
     * @return bool Success status
     */
    public function deleteVoiceProfile(string $voiceId): bool
    {
        // Use ElevenLabs API to delete a voice
        $apiKey = config('services.elevenlabs.key');
        $endpoint = "https://api.elevenlabs.io/v1/voices/{$voiceId}";
        
        $response = Http::withHeaders([
            'xi-api-key' => $apiKey,
        ])->delete($endpoint);
        
        if (!$response->successful()) {
            throw new \Exception('Failed to delete voice profile: ' . $response->body());
        }
        
        return true;
    }
    
    /**
     * Download an audio file from a URL
     *
     * @param string $url The URL of the audio file
     * @return string The local path to the downloaded file
     */
    private function downloadAudioFile(string $url): string
    {
        $tempDir = storage_path('app/temp');
        if (!file_exists($tempDir)) {
            mkdir($tempDir, 0755, true);
        }
        
        $localPath = $tempDir . '/' . uniqid() . '.audio';
        
        $response = Http::withOptions([
            'sink' => $localPath,
        ])->get($url);
        
        if (!$response->successful()) {
            throw new \Exception('Failed to download audio file: ' . $response->status());
        }
        
        return $localPath;
    }
    
    /**
     * Extract gender from voice labels
     *
     * @param array $labels The voice labels
     * @return string The gender
     */
    private function extractGenderFromLabels(array $labels): string
    {
        if (isset($labels['gender'])) {
            return $labels['gender'];
        }
        
        // Default to neutral if not specified
        return 'neutral';
    }
    
    /**
     * Calculate approximate audio duration based on text length and speed
     *
     * @param string $text The text
     * @param float $speed The speech speed
     * @return float The duration in seconds
     */
    private function calculateAudioDuration(string $text, float $speed): float
    {
        // Average speaking rate is about 150 words per minute
        $wordCount = str_word_count($text);
        $minutesAtNormalSpeed = $wordCount / 150;
        $seconds = $minutesAtNormalSpeed * 60;
        
        // Adjust for speed
        return $seconds / $speed;
    }
    
    /**
     * Track the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return void
     */
    public function trackCost(string $operation, array $parameters): void
    {
        $cost = $this->calculateOperationCost($operation, $parameters);
        
        // Log the cost
        $costTracking = new OperationCost();
        $costTracking->operation = $operation;
        $costTracking->parameters = $parameters;
        $costTracking->cost = $cost;
        $costTracking->timestamp = Carbon::now();
        $costTracking->service = 'voice-generation';
        $costTracking->save();
        
        Log::info("Cost tracked for {$operation}: \${$cost}", $parameters);
    }
    
    /**
     * Calculate the cost of an operation
     *
     * @param string $operation The operation name
     * @param array $parameters The operation parameters
     * @return float The cost in USD
     */
    private function calculateOperationCost(string $operation, array $parameters): float
    {
        switch ($operation) {
            case 'create-voice-profile':
                // ElevenLabs: $0.50 per voice profile
                return 0.50;
                
            case 'generate-speech':
                // ElevenLabs: $0.006 per 1000 characters
                $textLength = $parameters['text_length'] ?? 0;
                return ($textLength / 1000) * 0.006;
                
            default:
                return 0.0;
        }
    }
}
