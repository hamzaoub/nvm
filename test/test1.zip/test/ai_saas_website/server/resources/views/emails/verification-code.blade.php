@component('mail::message')
# Email Verification Code

Thank you for registering with our application. To complete your registration, please use the following verification code:

@component('mail::panel')
<div style="text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 5px;">{{ $code }}</div>
@endcomponent

This code will expire in 10 minutes.

If you did not request this verification code, please ignore this email.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
