<?php $__env->startComponent('mail::message'); ?>
# Email Verification Code

Thank you for registering with our application. To complete your registration, please use the following verification code:

<?php $__env->startComponent('mail::panel'); ?>
<div style="text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 5px;"><?php echo e($code); ?></div>
<?php echo $__env->renderComponent(); ?>

This code will expire in 10 minutes.

If you did not request this verification code, please ignore this email.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/bs/Desktop/GitHub/AIPRO/server/resources/views/emails/verification-code.blade.php ENDPATH**/ ?>