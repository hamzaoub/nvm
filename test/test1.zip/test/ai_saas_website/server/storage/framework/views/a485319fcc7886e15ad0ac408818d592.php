<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/bs/Desktop/GitHub/AIPRO/server/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>