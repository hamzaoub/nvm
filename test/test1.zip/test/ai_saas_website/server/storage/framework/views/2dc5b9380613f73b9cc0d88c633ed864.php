<?php echo e($slot); ?>

<?php /**PATH /Users/bs/Desktop/GitHub/AIPRO/server/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>