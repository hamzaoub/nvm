# AI SaaS Platform Integration Guide

## Overview

This document provides a comprehensive guide to the integration of the AWS API projects into the AI SaaS website. The integration uses Laravel controllers on the backend and React TypeScript components on the frontend, with AWS for request management and storage while leveraging third-party AI services for processing.

## Architecture

The integration follows a modern microservices architecture:

1. **Frontend**: React with TypeScript, using context providers for state management
2. **Backend**: Laravel controllers and services that proxy requests to third-party AI services
3. **Storage**: AWS S3 for file storage and AWS SQS for message queuing
4. **AI Processing**: Third-party services including Replicate, ElevenLabs, Deepgram, AssemblyAI, OpenAI, and Gretel

## Components

### Backend Components

1. **Controllers**: Located in `/server/app/Http/Controllers/AWS/`
   - `ContentTransformationController.php`
   - `MeetingAssistantController.php`
   - `VoiceGenerationController.php`
   - `CustomerJourneyController.php`
   - `SyntheticDataController.php`

2. **Services**: Located in `/server/app/Services/AWS/`
   - `ContentTransformationService.php`
   - `MeetingAssistantService.php`
   - `VoiceGenerationService.php`
   - `CustomerJourneyService.php`
   - `SyntheticDataService.php`

3. **Models**: Located in `/server/app/Models/`
   - Various model classes for each service domain

4. **Middleware**: Located in `/server/app/Http/Middleware/`
   - `MicroservicesAuthMiddleware.php`
   - `MicroservicesRateLimitMiddleware.php`
   - `MicroservicesCreditDeductionMiddleware.php`

### Frontend Components

1. **API Services**: Located in `/client/src/services/`
   - `api.ts`: Contains all API endpoints for the five microservices

2. **Context Providers**: Located in `/client/src/providers/`
   - `MicroservicesProvider.tsx`: Provides state management and API access

3. **UI Components**: Located in `/client/src/components/`
   - `TextToSpeechForm.tsx`
   - `ImageGenerationForm.tsx`
   - And other service-specific components

4. **Pages**: Located in `/client/src/pages/`
   - `DashboardPage.tsx`: Main dashboard interface

## Integration Points

### API Routes

The Laravel backend exposes the following API endpoints:

```
/api/content-transformation/text-to-speech
/api/content-transformation/speech-to-text
/api/content-transformation/text-to-image
/api/content-transformation/image-to-text
/api/content-transformation/text-to-video
/api/content-transformation/status/{jobId}

/api/meeting-assistant/join
/api/meeting-assistant/transcript/{meetingId}
/api/meeting-assistant/summary/{meetingId}
/api/meeting-assistant/action-items/{meetingId}
/api/meeting-assistant/upload

/api/voice-generation/profile
/api/voice-generation/profiles
/api/voice-generation/generate
/api/voice-generation/profile/{voiceId}

/api/customer-journey/track
/api/customer-journey/analyze/{userId}
/api/customer-journey/recommendations
/api/customer-journey/optimize-touchpoint

/api/synthetic-data/tabular
/api/synthetic-data/text
/api/synthetic-data/image
```

### Frontend-Backend Communication

The frontend communicates with the backend through the API service, which uses axios for HTTP requests. The MicroservicesProvider context manages state and provides hooks for components to access the API services.

## Third-Party Services Integration

### Content Transformation
- Text-to-Speech: ElevenLabs API
- Speech-to-Text: Deepgram API
- Text-to-Image: Replicate (Stable Diffusion) API
- Image-to-Text: Replicate (BLIP) API
- Text-to-Video: Replicate (Zeroscope) API

### Meeting Assistant
- Transcription: AssemblyAI API
- Summary Generation: OpenAI API
- Action Item Extraction: OpenAI API

### Voice Generation
- Voice Profile Creation: ElevenLabs API
- Speech Generation: ElevenLabs API

### Customer Journey
- Event Tracking: Mixpanel API
- Journey Analysis: OpenAI API
- Recommendation Generation: OpenAI API

### Synthetic Data
- Tabular Data Generation: Gretel API
- Text Data Generation: OpenAI API
- Image Data Generation: Replicate API

## Cost Structure

A detailed cost breakdown is available in the `cost_documentation.md` file. Key points:

- Each operation has a specific cost per request
- The system uses a credit-based model where 1 credit ≈ $0.01
- Different operations cost different amounts of credits
- Estimated total cost for 1,000 users: $7,490.72/month
- Recommended pricing tiers provide 75-80% profit margins

## Testing

Integration tests are available in the `/tests/integration/` directory:

1. `test_content_transformation.js`: Tests the Content Transformation API
2. `test_synthetic_data.js`: Tests the Synthetic Data API
3. `test_frontend_backend.js`: Tests the frontend-backend integration

Run the tests using the provided script:
```
./run_integration_tests.sh
```

## Deployment

The application can be deployed using the following steps:

1. Set up the Laravel backend on an AWS EC2 instance
2. Configure the necessary environment variables
3. Set up the database using the provided migrations
4. Build and deploy the React frontend
5. Configure AWS services (S3, SQS) as needed

## Conclusion

This integration successfully combines the AWS API projects with the AI SaaS website, providing a comprehensive platform for AI services. The use of third-party AI services instead of direct AWS AI services provides flexibility and cost-effectiveness while maintaining the same functionality.
