import React from 'react';
import { Box, Container, Typography, Paper, Grid, Divider, Chip } from '@mui/material';
import TextToSpeechForm from '../components/TextToSpeechForm';
import ImageGenerationForm from '../components/ImageGenerationForm';
import { useCosts } from '../providers/MicroservicesProvider';

const DashboardPage: React.FC = () => {
  const costs = useCosts();
  
  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 8 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        AI Services Dashboard
      </Typography>
      
      <Paper elevation={2} sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Service Overview
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0} 
              sx={{ 
                p: 2, 
                textAlign: 'center',
                bgcolor: 'primary.light',
                color: 'primary.contrastText',
                borderRadius: 2
              }}
            >
              <Typography variant="h5">5</Typography>
              <Typography variant="body2">AI Microservices</Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0} 
              sx={{ 
                p: 2, 
                textAlign: 'center',
                bgcolor: 'secondary.light',
                color: 'secondary.contrastText',
                borderRadius: 2
              }}
            >
              <Typography variant="h5">15+</Typography>
              <Typography variant="body2">AI Operations</Typography>
            </Paper>
          </Grid>
          <Grid item xs={12} md={4}>
            <Paper 
              elevation={0} 
              sx={{ 
                p: 2, 
                textAlign: 'center',
                bgcolor: 'success.light',
                color: 'success.contrastText',
                borderRadius: 2
              }}
            >
              <Typography variant="h5">300</Typography>
              <Typography variant="body2">Credits Available</Typography>
            </Paper>
          </Grid>
        </Grid>
      </Paper>
      
      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <TextToSpeechForm />
        </Grid>
        <Grid item xs={12} md={6}>
          <ImageGenerationForm />
        </Grid>
      </Grid>
      
      <Paper elevation={3} sx={{ p: 3, mt: 4 }}>
        <Typography variant="h5" gutterBottom>
          Service Cost Overview
        </Typography>
        <Divider sx={{ mb: 2 }} />
        
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Typography variant="subtitle1" gutterBottom>
              Cost Per Operation
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {Object.entries(costs.estimatedCostPerRequest).map(([key, value]) => (
                <Chip 
                  key={key} 
                  label={`${key}: $${value.toFixed(3)}`} 
                  variant="outlined" 
                  size="small"
                />
              ))}
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Typography variant="subtitle1" gutterBottom>
              Credit System
            </Typography>
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2">
                Each credit is worth approximately $0.01 in processing costs.
              </Typography>
              <Typography variant="body2">
                Operations cost between 1-72 credits depending on complexity.
              </Typography>
            </Box>
            <Typography variant="subtitle2" color="primary">
              Your current plan: Professional
            </Typography>
            <Typography variant="body2">
              300 credits remaining this month
            </Typography>
          </Grid>
        </Grid>
      </Paper>
    </Container>
  );
};

export default DashboardPage;
