import axios from 'axios';

// Base API URL
const API_URL = process.env.REACT_APP_API_URL || '/api';

// Content Transformation API
export const contentTransformationApi = {
  // Text to Speech transformation
  textToSpeech: async (text, voice = 'default', options = {}) => {
    try {
      const response = await axios.post(`${API_URL}/content-transformation/text-to-speech`, {
        text,
        voice,
        options
      });
      return response.data;
    } catch (error) {
      console.error('Error in textToSpeech:', error);
      throw error;
    }
  },

  // Speech to Text transformation
  speechToText: async (audioFile, language = 'en-US', options = {}) => {
    try {
      const formData = new FormData();
      formData.append('audio', audioFile);
      formData.append('language', language);
      formData.append('options', JSON.stringify(options));

      const response = await axios.post(`${API_URL}/content-transformation/speech-to-text`, 
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error in speechToText:', error);
      throw error;
    }
  },

  // Text to Image transformation
  textToImage: async (prompt, style = 'realistic', size = '512x512', options = {}) => {
    try {
      const response = await axios.post(`${API_URL}/content-transformation/text-to-image`, {
        prompt,
        style,
        size,
        options
      });
      return response.data;
    } catch (error) {
      console.error('Error in textToImage:', error);
      throw error;
    }
  },

  // Image to Text transformation (image captioning)
  imageToText: async (imageFile, options = {}) => {
    try {
      const formData = new FormData();
      formData.append('image', imageFile);
      formData.append('options', JSON.stringify(options));

      const response = await axios.post(`${API_URL}/content-transformation/image-to-text`, 
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error in imageToText:', error);
      throw error;
    }
  },

  // Text to Video transformation
  textToVideo: async (prompt, duration = 5, style = 'realistic', options = {}) => {
    try {
      const response = await axios.post(`${API_URL}/content-transformation/text-to-video`, {
        prompt,
        duration,
        style,
        options
      });
      return response.data;
    } catch (error) {
      console.error('Error in textToVideo:', error);
      throw error;
    }
  },

  // Check transformation status
  checkStatus: async (jobId) => {
    try {
      const response = await axios.get(`${API_URL}/content-transformation/status/${jobId}`);
      return response.data;
    } catch (error) {
      console.error('Error in checkStatus:', error);
      throw error;
    }
  }
};

// Meeting Assistant API
export const meetingAssistantApi = {
  // Join a meeting
  joinMeeting: async (meetingUrl, options = {}) => {
    try {
      const response = await axios.post(`${API_URL}/meeting-assistant/join`, {
        meeting_url: meetingUrl,
        options
      });
      return response.data;
    } catch (error) {
      console.error('Error in joinMeeting:', error);
      throw error;
    }
  },

  // Get meeting transcript
  getTranscript: async (meetingId) => {
    try {
      const response = await axios.get(`${API_URL}/meeting-assistant/transcript/${meetingId}`);
      return response.data;
    } catch (error) {
      console.error('Error in getTranscript:', error);
      throw error;
    }
  },

  // Get meeting summary
  getSummary: async (meetingId, format = 'text') => {
    try {
      const response = await axios.get(`${API_URL}/meeting-assistant/summary/${meetingId}?format=${format}`);
      return response.data;
    } catch (error) {
      console.error('Error in getSummary:', error);
      throw error;
    }
  },

  // Get action items from meeting
  getActionItems: async (meetingId) => {
    try {
      const response = await axios.get(`${API_URL}/meeting-assistant/action-items/${meetingId}`);
      return response.data;
    } catch (error) {
      console.error('Error in getActionItems:', error);
      throw error;
    }
  },

  // Upload meeting recording for processing
  uploadRecording: async (recordingFile, metadata = {}) => {
    try {
      const formData = new FormData();
      formData.append('recording', recordingFile);
      formData.append('metadata', JSON.stringify(metadata));

      const response = await axios.post(`${API_URL}/meeting-assistant/upload`, 
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error in uploadRecording:', error);
      throw error;
    }
  }
};

// Voice Generation API
export const voiceGenerationApi = {
  // Create a voice profile
  createVoiceProfile: async (name, audioFile, description = '') => {
    try {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('audio', audioFile);
      formData.append('description', description);

      const response = await axios.post(`${API_URL}/voice-generation/profile`, 
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      return response.data;
    } catch (error) {
      console.error('Error in createVoiceProfile:', error);
      throw error;
    }
  },

  // List available voice profiles
  listVoiceProfiles: async () => {
    try {
      const response = await axios.get(`${API_URL}/voice-generation/profiles`);
      return response.data;
    } catch (error) {
      console.error('Error in listVoiceProfiles:', error);
      throw error;
    }
  },

  // Generate speech using a voice profile
  generateSpeech: async (text, voiceId, options = {}) => {
    try {
      const response = await axios.post(`${API_URL}/voice-generation/generate`, {
        text,
        voice_id: voiceId,
        options
      });
      return response.data;
    } catch (error) {
      console.error('Error in generateSpeech:', error);
      throw error;
    }
  },

  // Delete a voice profile
  deleteVoiceProfile: async (voiceId) => {
    try {
      const response = await axios.delete(`${API_URL}/voice-generation/profile/${voiceId}`);
      return response.data;
    } catch (error) {
      console.error('Error in deleteVoiceProfile:', error);
      throw error;
    }
  }
};

// Customer Journey API
export const customerJourneyApi = {
  // Track a customer journey event
  trackEvent: async (userId, eventType, eventData) => {
    try {
      const response = await axios.post(`${API_URL}/customer-journey/track`, {
        user_id: userId,
        event_type: eventType,
        event_data: eventData
      });
      return response.data;
    } catch (error) {
      console.error('Error in trackEvent:', error);
      throw error;
    }
  },

  // Analyze a user's journey
  analyzeUserJourney: async (userId, startDate = null, endDate = null) => {
    try {
      const params = new URLSearchParams();
      if (startDate) params.append('start_date', startDate);
      if (endDate) params.append('end_date', endDate);

      const response = await axios.get(`${API_URL}/customer-journey/analyze/${userId}?${params.toString()}`);
      return response.data;
    } catch (error) {
      console.error('Error in analyzeUserJourney:', error);
      throw error;
    }
  },

  // Generate recommendations for a user
  generateRecommendations: async (userId, userProfile, recentEvents) => {
    try {
      const response = await axios.post(`${API_URL}/customer-journey/recommendations`, {
        user_id: userId,
        user_profile: userProfile,
        recent_events: recentEvents
      });
      return response.data;
    } catch (error) {
      console.error('Error in generateRecommendations:', error);
      throw error;
    }
  },

  // Optimize a specific touchpoint
  optimizeTouchpoint: async (touchpointId, touchpointData, performanceMetrics) => {
    try {
      const response = await axios.post(`${API_URL}/customer-journey/optimize-touchpoint`, {
        touchpoint_id: touchpointId,
        touchpoint_data: touchpointData,
        performance_metrics: performanceMetrics
      });
      return response.data;
    } catch (error) {
      console.error('Error in optimizeTouchpoint:', error);
      throw error;
    }
  }
};

// Synthetic Data API
export const syntheticDataApi = {
  // Generate synthetic tabular data
  generateTabularData: async (schema, rows = 100, constraints = []) => {
    try {
      const response = await axios.post(`${API_URL}/synthetic-data/tabular`, {
        schema,
        rows,
        constraints
      });
      return response.data;
    } catch (error) {
      console.error('Error in generateTabularData:', error);
      throw error;
    }
  },

  // Generate synthetic text data
  generateTextData: async (prompt, category = 'general', count = 5, maxLength = 200) => {
    try {
      const response = await axios.post(`${API_URL}/synthetic-data/text`, {
        prompt,
        category,
        count,
        max_length: maxLength
      });
      return response.data;
    } catch (error) {
      console.error('Error in generateTextData:', error);
      throw error;
    }
  },

  // Generate synthetic image data
  generateImageData: async (prompt, style = 'realistic', size = '512x512', count = 1) => {
    try {
      const response = await axios.post(`${API_URL}/synthetic-data/image`, {
        prompt,
        style,
        size,
        count
      });
      return response.data;
    } catch (error) {
      console.error('Error in generateImageData:', error);
      throw error;
    }
  }
};

// Export all APIs
export default {
  contentTransformation: contentTransformationApi,
  meetingAssistant: meetingAssistantApi,
  voiceGeneration: voiceGenerationApi,
  customerJourney: customerJourneyApi,
  syntheticData: syntheticDataApi
};
