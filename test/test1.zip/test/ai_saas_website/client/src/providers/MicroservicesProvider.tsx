import React, { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { contentTransformationApi, meetingAssistantApi, voiceGenerationApi, customerJourneyApi, syntheticDataApi } from '../services/api';

// Define types for each service's state
interface ContentTransformationState {
  loading: boolean;
  error: string | null;
  jobs: Record<string, any>;
  transformText: (text: string, targetFormat: string, options?: any) => Promise<any>;
  checkJobStatus: (jobId: string) => Promise<any>;
}

interface MeetingAssistantState {
  loading: boolean;
  error: string | null;
  meetings: Record<string, any>;
  joinMeeting: (meetingUrl: string, options?: any) => Promise<any>;
  getTranscript: (meetingId: string) => Promise<any>;
  getSummary: (meetingId: string, format?: string) => Promise<any>;
  getActionItems: (meetingId: string) => Promise<any>;
}

interface VoiceGenerationState {
  loading: boolean;
  error: string | null;
  profiles: any[];
  createProfile: (name: string, audioFile: File, description?: string) => Promise<any>;
  generateSpeech: (text: string, voiceId: string, options?: any) => Promise<any>;
  listProfiles: () => Promise<any>;
}

interface CustomerJourneyState {
  loading: boolean;
  error: string | null;
  trackEvent: (userId: string, eventType: string, eventData: any) => Promise<any>;
  analyzeJourney: (userId: string, startDate?: string, endDate?: string) => Promise<any>;
  getRecommendations: (userId: string, userProfile: any, recentEvents: any[]) => Promise<any>;
}

interface SyntheticDataState {
  loading: boolean;
  error: string | null;
  generateTabularData: (schema: any[], rows?: number, constraints?: any[]) => Promise<any>;
  generateTextData: (prompt: string, category?: string, count?: number, maxLength?: number) => Promise<any>;
  generateImageData: (prompt: string, style?: string, size?: string, count?: number) => Promise<any>;
}

// Define the overall context state
interface MicroservicesContextState {
  contentTransformation: ContentTransformationState;
  meetingAssistant: MeetingAssistantState;
  voiceGeneration: VoiceGenerationState;
  customerJourney: CustomerJourneyState;
  syntheticData: SyntheticDataState;
  costs: {
    estimatedCostPerRequest: Record<string, number>;
    totalCostToDate: number;
  };
}

// Create the context
const MicroservicesContext = createContext<MicroservicesContextState | undefined>(undefined);

// Provider props
interface MicroservicesProviderProps {
  children: ReactNode;
}

// Provider component
export const MicroservicesProvider: React.FC<MicroservicesProviderProps> = ({ children }) => {
  // Content Transformation State
  const [contentTransformationState, setContentTransformationState] = useState<ContentTransformationState>({
    loading: false,
    error: null,
    jobs: {},
    transformText: async (text, targetFormat, options = {}) => {
      setContentTransformationState(prev => ({ ...prev, loading: true, error: null }));
      try {
        let result;
        switch (targetFormat) {
          case 'speech':
            result = await contentTransformationApi.textToSpeech(text, options.voice, options);
            break;
          case 'image':
            result = await contentTransformationApi.textToImage(text, options.style, options.size, options);
            break;
          case 'video':
            result = await contentTransformationApi.textToVideo(text, options.duration, options.style, options);
            break;
          default:
            throw new Error(`Unsupported transformation target: ${targetFormat}`);
        }
        
        setContentTransformationState(prev => ({
          ...prev,
          loading: false,
          jobs: { ...prev.jobs, [result.job_id]: result }
        }));
        
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setContentTransformationState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    checkJobStatus: async (jobId) => {
      setContentTransformationState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await contentTransformationApi.checkStatus(jobId);
        setContentTransformationState(prev => ({
          ...prev,
          loading: false,
          jobs: { ...prev.jobs, [jobId]: { ...prev.jobs[jobId], ...result } }
        }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setContentTransformationState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    }
  });

  // Meeting Assistant State
  const [meetingAssistantState, setMeetingAssistantState] = useState<MeetingAssistantState>({
    loading: false,
    error: null,
    meetings: {},
    joinMeeting: async (meetingUrl, options = {}) => {
      setMeetingAssistantState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await meetingAssistantApi.joinMeeting(meetingUrl, options);
        setMeetingAssistantState(prev => ({
          ...prev,
          loading: false,
          meetings: { ...prev.meetings, [result.meeting_id]: result }
        }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setMeetingAssistantState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    getTranscript: async (meetingId) => {
      setMeetingAssistantState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await meetingAssistantApi.getTranscript(meetingId);
        setMeetingAssistantState(prev => ({
          ...prev,
          loading: false,
          meetings: { 
            ...prev.meetings, 
            [meetingId]: { 
              ...prev.meetings[meetingId], 
              transcript: result.transcript 
            } 
          }
        }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setMeetingAssistantState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    getSummary: async (meetingId, format = 'text') => {
      setMeetingAssistantState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await meetingAssistantApi.getSummary(meetingId, format);
        setMeetingAssistantState(prev => ({
          ...prev,
          loading: false,
          meetings: { 
            ...prev.meetings, 
            [meetingId]: { 
              ...prev.meetings[meetingId], 
              summary: result.summary 
            } 
          }
        }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setMeetingAssistantState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    getActionItems: async (meetingId) => {
      setMeetingAssistantState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await meetingAssistantApi.getActionItems(meetingId);
        setMeetingAssistantState(prev => ({
          ...prev,
          loading: false,
          meetings: { 
            ...prev.meetings, 
            [meetingId]: { 
              ...prev.meetings[meetingId], 
              actionItems: result.action_items 
            } 
          }
        }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setMeetingAssistantState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    }
  });

  // Voice Generation State
  const [voiceGenerationState, setVoiceGenerationState] = useState<VoiceGenerationState>({
    loading: false,
    error: null,
    profiles: [],
    createProfile: async (name, audioFile, description = '') => {
      setVoiceGenerationState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await voiceGenerationApi.createVoiceProfile(name, audioFile, description);
        setVoiceGenerationState(prev => ({
          ...prev,
          loading: false,
          profiles: [...prev.profiles, result.profile]
        }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setVoiceGenerationState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    generateSpeech: async (text, voiceId, options = {}) => {
      setVoiceGenerationState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await voiceGenerationApi.generateSpeech(text, voiceId, options);
        setVoiceGenerationState(prev => ({ ...prev, loading: false }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setVoiceGenerationState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    listProfiles: async () => {
      setVoiceGenerationState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await voiceGenerationApi.listVoiceProfiles();
        setVoiceGenerationState(prev => ({
          ...prev,
          loading: false,
          profiles: result.profiles
        }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setVoiceGenerationState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    }
  });

  // Customer Journey State
  const [customerJourneyState, setCustomerJourneyState] = useState<CustomerJourneyState>({
    loading: false,
    error: null,
    trackEvent: async (userId, eventType, eventData) => {
      setCustomerJourneyState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await customerJourneyApi.trackEvent(userId, eventType, eventData);
        setCustomerJourneyState(prev => ({ ...prev, loading: false }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setCustomerJourneyState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    analyzeJourney: async (userId, startDate, endDate) => {
      setCustomerJourneyState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await customerJourneyApi.analyzeUserJourney(userId, startDate, endDate);
        setCustomerJourneyState(prev => ({ ...prev, loading: false }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setCustomerJourneyState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    getRecommendations: async (userId, userProfile, recentEvents) => {
      setCustomerJourneyState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await customerJourneyApi.generateRecommendations(userId, userProfile, recentEvents);
        setCustomerJourneyState(prev => ({ ...prev, loading: false }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setCustomerJourneyState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    }
  });

  // Synthetic Data State
  const [syntheticDataState, setSyntheticDataState] = useState<SyntheticDataState>({
    loading: false,
    error: null,
    generateTabularData: async (schema, rows = 100, constraints = []) => {
      setSyntheticDataState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await syntheticDataApi.generateTabularData(schema, rows, constraints);
        setSyntheticDataState(prev => ({ ...prev, loading: false }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setSyntheticDataState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    generateTextData: async (prompt, category = 'general', count = 5, maxLength = 200) => {
      setSyntheticDataState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await syntheticDataApi.generateTextData(prompt, category, count, maxLength);
        setSyntheticDataState(prev => ({ ...prev, loading: false }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setSyntheticDataState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    },
    generateImageData: async (prompt, style = 'realistic', size = '512x512', count = 1) => {
      setSyntheticDataState(prev => ({ ...prev, loading: true, error: null }));
      try {
        const result = await syntheticDataApi.generateImageData(prompt, style, size, count);
        setSyntheticDataState(prev => ({ ...prev, loading: false }));
        return result;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        setSyntheticDataState(prev => ({ ...prev, loading: false, error: errorMessage }));
        throw error;
      }
    }
  });

  // Cost information
  const [costs] = useState({
    estimatedCostPerRequest: {
      'text-to-speech': 0.016,
      'speech-to-text': 0.036,
      'text-to-image': 0.020,
      'image-to-text': 0.015,
      'text-to-video': 0.080,
      'join-meeting': 0.050,
      'meeting-transcript': 0.720,
      'meeting-summary': 0.030,
      'create-voice-profile': 0.500,
      'generate-speech': 0.032,
      'track-event': 0.0001,
      'analyze-journey': 0.010,
      'generate-recommendations': 0.015,
      'generate-tabular-data': 0.002,
      'generate-text-data': 0.008,
      'generate-image-data': 0.002
    },
    totalCostToDate: 0
  });

  // Load voice profiles on mount
  useEffect(() => {
    voiceGenerationState.listProfiles().catch(console.error);
  }, []);

  // Combine all states into the context value
  const contextValue: MicroservicesContextState = {
    contentTransformation: contentTransformationState,
    meetingAssistant: meetingAssistantState,
    voiceGeneration: voiceGenerationState,
    customerJourney: customerJourneyState,
    syntheticData: syntheticDataState,
    costs
  };

  return (
    <MicroservicesContext.Provider value={contextValue}>
      {children}
    </MicroservicesContext.Provider>
  );
};

// Custom hook to use the microservices context
export const useMicroservices = () => {
  const context = useContext(MicroservicesContext);
  if (context === undefined) {
    throw new Error('useMicroservices must be used within a MicroservicesProvider');
  }
  return context;
};

// Export individual hooks for each service
export const useContentTransformation = () => {
  const { contentTransformation } = useMicroservices();
  return contentTransformation;
};

export const useMeetingAssistant = () => {
  const { meetingAssistant } = useMicroservices();
  return meetingAssistant;
};

export const useVoiceGeneration = () => {
  const { voiceGeneration } = useMicroservices();
  return voiceGeneration;
};

export const useCustomerJourney = () => {
  const { customerJourney } = useMicroservices();
  return customerJourney;
};

export const useSyntheticData = () => {
  const { syntheticData } = useMicroservices();
  return syntheticData;
};

export const useCosts = () => {
  const { costs } = useMicroservices();
  return costs;
};
