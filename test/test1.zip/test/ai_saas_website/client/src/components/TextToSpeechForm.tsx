import React, { useState } from 'react';
import { useContentTransformation } from '../providers/MicroservicesProvider';
import { Box, Button, TextField, Typography, CircularProgress, Alert, Paper, Grid, MenuItem, Select, FormControl, InputLabel, SelectChangeEvent } from '@mui/material';

interface TextToSpeechFormProps {
  onComplete?: (audioUrl: string) => void;
}

const TextToSpeechForm: React.FC<TextToSpeechFormProps> = ({ onComplete }) => {
  const [text, setText] = useState('');
  const [voice, setVoice] = useState('default');
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [jobId, setJobId] = useState<string | null>(null);
  const [pollingInterval, setPollingInterval] = useState<NodeJS.Timeout | null>(null);
  
  const { transformText, checkJobStatus, loading, error, jobs } = useContentTransformation();

  const handleVoiceChange = (event: SelectChangeEvent) => {
    setVoice(event.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!text.trim()) return;
    
    try {
      const result = await transformText(text, 'speech', { voice });
      setJobId(result.job_id);
      
      // Start polling for job status
      const interval = setInterval(async () => {
        const status = await checkJobStatus(result.job_id);
        
        if (status.status === 'completed') {
          setAudioUrl(status.result.audio_url);
          if (onComplete) onComplete(status.result.audio_url);
          
          // Clear polling interval
          if (pollingInterval) {
            clearInterval(pollingInterval);
            setPollingInterval(null);
          }
        } else if (status.status === 'failed') {
          // Clear polling interval
          if (pollingInterval) {
            clearInterval(pollingInterval);
            setPollingInterval(null);
          }
        }
      }, 2000);
      
      setPollingInterval(interval);
    } catch (err) {
      console.error('Error transforming text to speech:', err);
    }
  };

  // Clean up interval on unmount
  React.useEffect(() => {
    return () => {
      if (pollingInterval) {
        clearInterval(pollingInterval);
      }
    };
  }, [pollingInterval]);

  const currentJob = jobId ? jobs[jobId] : null;
  const jobStatus = currentJob?.status || 'pending';

  return (
    <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
      <Typography variant="h5" component="h2" gutterBottom>
        Text to Speech Conversion
      </Typography>
      
      <form onSubmit={handleSubmit}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              multiline
              rows={4}
              label="Text to convert"
              value={text}
              onChange={(e) => setText(e.target.value)}
              disabled={loading}
              required
            />
          </Grid>
          
          <Grid item xs={12}>
            <FormControl fullWidth>
              <InputLabel id="voice-select-label">Voice</InputLabel>
              <Select
                labelId="voice-select-label"
                value={voice}
                label="Voice"
                onChange={handleVoiceChange}
                disabled={loading}
              >
                <MenuItem value="default">Default</MenuItem>
                <MenuItem value="male">Male</MenuItem>
                <MenuItem value="female">Female</MenuItem>
                <MenuItem value="child">Child</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12}>
            <Button 
              type="submit" 
              variant="contained" 
              color="primary" 
              disabled={loading || !text.trim()}
              fullWidth
            >
              {loading ? <CircularProgress size={24} /> : 'Convert to Speech'}
            </Button>
          </Grid>
        </Grid>
      </form>
      
      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error}
        </Alert>
      )}
      
      {jobId && jobStatus === 'processing' && (
        <Box sx={{ mt: 2, textAlign: 'center' }}>
          <CircularProgress size={24} sx={{ mr: 1 }} />
          <Typography variant="body2" component="span">
            Processing your audio...
          </Typography>
        </Box>
      )}
      
      {audioUrl && (
        <Box sx={{ mt: 3 }}>
          <Typography variant="subtitle1" gutterBottom>
            Generated Audio:
          </Typography>
          <audio controls src={audioUrl} style={{ width: '100%' }}>
            Your browser does not support the audio element.
          </audio>
          <Typography variant="caption" color="text.secondary">
            Estimated cost: $0.016
          </Typography>
        </Box>
      )}
    </Paper>
  );
};

export default TextToSpeechForm;
