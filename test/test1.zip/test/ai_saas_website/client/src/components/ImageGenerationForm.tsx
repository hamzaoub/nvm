import React, { useState } from 'react';
import { useSyntheticData } from '../providers/MicroservicesProvider';
import { 
  Box, 
  Button, 
  TextField, 
  Typography, 
  CircularProgress, 
  Alert, 
  Paper, 
  Grid, 
  MenuItem, 
  Select, 
  FormControl, 
  InputLabel, 
  SelectChangeEvent,
  Card,
  CardMedia,
  CardContent
} from '@mui/material';

const ImageGenerationForm: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState('realistic');
  const [size, setSize] = useState('512x512');
  const [count, setCount] = useState(1);
  const [generatedImages, setGeneratedImages] = useState<Array<{url: string, size: string, format: string}>>([]);
  
  const { generateImageData, loading, error } = useSyntheticData();

  const handleStyleChange = (event: SelectChangeEvent) => {
    setStyle(event.target.value);
  };

  const handleSizeChange = (event: SelectChangeEvent) => {
    setSize(event.target.value);
  };

  const handleCountChange = (event: SelectChangeEvent) => {
    setCount(Number(event.target.value));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!prompt.trim()) return;
    
    try {
      const result = await generateImageData(prompt, style, size, count);
      setGeneratedImages(result.data.images);
    } catch (err) {
      console.error('Error generating images:', err);
    }
  };

  return (
    <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
      <Typography variant="h5" component="h2" gutterBottom>
        AI Image Generation
      </Typography>
      
      <form onSubmit={handleSubmit}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Image description"
              placeholder="A serene lake surrounded by mountains at sunset"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              disabled={loading}
              required
            />
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth>
              <InputLabel id="style-select-label">Style</InputLabel>
              <Select
                labelId="style-select-label"
                value={style}
                label="Style"
                onChange={handleStyleChange}
                disabled={loading}
              >
                <MenuItem value="realistic">Realistic</MenuItem>
                <MenuItem value="digital_art">Digital Art</MenuItem>
                <MenuItem value="anime">Anime</MenuItem>
                <MenuItem value="painting">Painting</MenuItem>
                <MenuItem value="sketch">Sketch</MenuItem>
                <MenuItem value="watercolor">Watercolor</MenuItem>
                <MenuItem value="pixel_art">Pixel Art</MenuItem>
                <MenuItem value="fantasy">Fantasy</MenuItem>
                <MenuItem value="sci_fi">Sci-Fi</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth>
              <InputLabel id="size-select-label">Size</InputLabel>
              <Select
                labelId="size-select-label"
                value={size}
                label="Size"
                onChange={handleSizeChange}
                disabled={loading}
              >
                <MenuItem value="256x256">Small (256x256)</MenuItem>
                <MenuItem value="512x512">Medium (512x512)</MenuItem>
                <MenuItem value="1024x1024">Large (1024x1024)</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth>
              <InputLabel id="count-select-label">Number of Images</InputLabel>
              <Select
                labelId="count-select-label"
                value={count.toString()}
                label="Number of Images"
                onChange={handleCountChange}
                disabled={loading}
              >
                <MenuItem value="1">1</MenuItem>
                <MenuItem value="2">2</MenuItem>
                <MenuItem value="3">3</MenuItem>
                <MenuItem value="4">4</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          
          <Grid item xs={12}>
            <Button 
              type="submit" 
              variant="contained" 
              color="primary" 
              disabled={loading || !prompt.trim()}
              fullWidth
            >
              {loading ? <CircularProgress size={24} /> : 'Generate Images'}
            </Button>
          </Grid>
        </Grid>
      </form>
      
      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error}
        </Alert>
      )}
      
      {loading && (
        <Box sx={{ mt: 2, textAlign: 'center' }}>
          <CircularProgress size={24} sx={{ mr: 1 }} />
          <Typography variant="body2" component="span">
            Generating your images... This may take up to 30 seconds.
          </Typography>
        </Box>
      )}
      
      {generatedImages.length > 0 && (
        <Box sx={{ mt: 3 }}>
          <Typography variant="subtitle1" gutterBottom>
            Generated Images:
          </Typography>
          <Grid container spacing={2}>
            {generatedImages.map((image, index) => (
              <Grid item xs={12} sm={6} md={count > 2 ? 3 : 6} key={index}>
                <Card>
                  <CardMedia
                    component="img"
                    image={image.url}
                    alt={`Generated image ${index + 1}`}
                    sx={{ height: 250, objectFit: 'contain' }}
                  />
                  <CardContent>
                    <Typography variant="caption" color="text.secondary">
                      Size: {image.size} • Format: {image.format}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
            Estimated cost: ${(0.002 * count).toFixed(3)}
          </Typography>
        </Box>
      )}
    </Paper>
  );
};

export default ImageGenerationForm;
