#!/bin/bash

# Integration Test Script for AI SaaS Website
# This script tests the integration between Laravel backend and React frontend

echo "Starting integration tests for AI SaaS Website..."

# Create test directory
mkdir -p /home/ubuntu/ai_saas_website/tests/integration

# Test 1: Content Transformation API Integration
echo "Testing Content Transformation API Integration..."
cat > /home/ubuntu/ai_saas_website/tests/integration/test_content_transformation.js << 'EOL'
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

const API_URL = process.env.API_URL || 'http://localhost:8000/api';

async function testTextToSpeech() {
  try {
    const response = await axios.post(`${API_URL}/content-transformation/text-to-speech`, {
      text: 'This is a test of the text to speech transformation API.',
      voice: 'default',
      options: {}
    });
    
    console.log('Text to Speech Test:', response.data.status === 'success' ? 'PASSED' : 'FAILED');
    console.log('Job ID:', response.data.job_id);
    return response.data.job_id;
  } catch (error) {
    console.error('Text to Speech Test FAILED:', error.message);
    return null;
  }
}

async function testCheckStatus(jobId) {
  if (!jobId) return;
  
  try {
    const response = await axios.get(`${API_URL}/content-transformation/status/${jobId}`);
    console.log('Check Status Test:', response.data.status ? 'PASSED' : 'FAILED');
    console.log('Job Status:', response.data.status);
  } catch (error) {
    console.error('Check Status Test FAILED:', error.message);
  }
}

async function runTests() {
  const jobId = await testTextToSpeech();
  await new Promise(resolve => setTimeout(resolve, 2000));
  await testCheckStatus(jobId);
}

runTests();
EOL

# Test 2: Synthetic Data API Integration
echo "Testing Synthetic Data API Integration..."
cat > /home/ubuntu/ai_saas_website/tests/integration/test_synthetic_data.js << 'EOL'
const axios = require('axios');

const API_URL = process.env.API_URL || 'http://localhost:8000/api';

async function testGenerateTabularData() {
  try {
    const schema = [
      { name: 'id', type: 'integer' },
      { name: 'name', type: 'string' },
      { name: 'email', type: 'email' },
      { name: 'age', type: 'integer', min: 18, max: 65 }
    ];
    
    const response = await axios.post(`${API_URL}/synthetic-data/tabular`, {
      schema,
      rows: 5,
      constraints: []
    });
    
    console.log('Generate Tabular Data Test:', response.data.status === 'success' ? 'PASSED' : 'FAILED');
    console.log('Generated Rows:', response.data.data.length);
    return response.data;
  } catch (error) {
    console.error('Generate Tabular Data Test FAILED:', error.message);
    return null;
  }
}

async function testGenerateImageData() {
  try {
    const response = await axios.post(`${API_URL}/synthetic-data/image`, {
      prompt: 'A beautiful mountain landscape with a lake',
      style: 'realistic',
      size: '256x256',
      count: 1
    });
    
    console.log('Generate Image Data Test:', response.data.status === 'success' ? 'PASSED' : 'FAILED');
    console.log('Generated Images:', response.data.data.images.length);
    return response.data;
  } catch (error) {
    console.error('Generate Image Data Test FAILED:', error.message);
    return null;
  }
}

async function runTests() {
  await testGenerateTabularData();
  await testGenerateImageData();
}

runTests();
EOL

# Test 3: Frontend-Backend Integration
echo "Testing Frontend-Backend Integration..."
cat > /home/ubuntu/ai_saas_website/tests/integration/test_frontend_backend.js << 'EOL'
const puppeteer = require('puppeteer');

async function testFrontendBackendIntegration() {
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  
  try {
    const page = await browser.newPage();
    await page.goto('http://localhost:3000');
    
    // Test 1: Check if the page loads
    const title = await page.title();
    console.log('Page Load Test:', title.includes('AI SaaS') ? 'PASSED' : 'FAILED');
    
    // Test 2: Check if the TextToSpeech component renders
    const textToSpeechExists = await page.evaluate(() => {
      return document.querySelector('form textarea') !== null;
    });
    console.log('TextToSpeech Component Test:', textToSpeechExists ? 'PASSED' : 'FAILED');
    
    // Test 3: Check if the ImageGeneration component renders
    const imageGenerationExists = await page.evaluate(() => {
      return document.querySelector('input[placeholder*="Image description"]') !== null;
    });
    console.log('ImageGeneration Component Test:', imageGenerationExists ? 'PASSED' : 'FAILED');
    
    // Test 4: Submit a text-to-speech request
    if (textToSpeechExists) {
      await page.type('form textarea', 'This is a test of the text to speech functionality.');
      await page.click('form button[type="submit"]');
      
      // Wait for the loading indicator
      await page.waitForSelector('form button[type="submit"] .MuiCircularProgress-root', { timeout: 5000 })
        .then(() => console.log('Loading Indicator Test: PASSED'))
        .catch(() => console.log('Loading Indicator Test: FAILED'));
    }
    
  } catch (error) {
    console.error('Frontend-Backend Integration Test FAILED:', error.message);
  } finally {
    await browser.close();
  }
}

testFrontendBackendIntegration();
EOL

# Create a mock setup script
echo "Creating mock setup for testing..."
cat > /home/ubuntu/ai_saas_website/tests/integration/setup_mock_environment.js << 'EOL'
const express = require('express');
const cors = require('cors');
const app = express();
const port = 8000;

app.use(cors());
app.use(express.json());

// Mock Content Transformation API
app.post('/api/content-transformation/text-to-speech', (req, res) => {
  res.json({
    status: 'success',
    job_id: 'mock-job-' + Date.now(),
    message: 'Text to speech conversion job started'
  });
});

app.get('/api/content-transformation/status/:jobId', (req, res) => {
  res.json({
    status: 'processing',
    job_id: req.params.jobId,
    progress: 30,
    message: 'Processing text to speech conversion'
  });
});

// Mock Synthetic Data API
app.post('/api/synthetic-data/tabular', (req, res) => {
  const { schema, rows } = req.body;
  const mockData = Array(rows || 5).fill().map((_, i) => {
    const row = {};
    schema.forEach(field => {
      if (field.type === 'integer') {
        row[field.name] = Math.floor(Math.random() * 100);
      } else if (field.type === 'email') {
        row[field.name] = `user${i}@example.com`;
      } else {
        row[field.name] = `Sample ${field.name} ${i}`;
      }
    });
    return row;
  });
  
  res.json({
    status: 'success',
    data: mockData,
    message: 'Tabular data generated successfully'
  });
});

app.post('/api/synthetic-data/image', (req, res) => {
  res.json({
    status: 'success',
    data: {
      images: [{
        url: 'https://via.placeholder.com/512x512.png?text=AI+Generated+Image',
        size: '512x512',
        format: 'png'
      }]
    },
    message: 'Image generated successfully'
  });
});

app.listen(port, () => {
  console.log(`Mock API server running at http://localhost:${port}`);
});
EOL

# Create a test runner script
echo "Creating test runner script..."
cat > /home/ubuntu/ai_saas_website/run_integration_tests.sh << 'EOL'
#!/bin/bash

# Start the mock API server
echo "Starting mock API server..."
node tests/integration/setup_mock_environment.js &
MOCK_PID=$!

# Wait for the server to start
sleep 2

# Run the integration tests
echo "Running Content Transformation API test..."
node tests/integration/test_content_transformation.js

echo "Running Synthetic Data API test..."
node tests/integration/test_synthetic_data.js

# Kill the mock server
echo "Stopping mock API server..."
kill $MOCK_PID

echo "Integration tests completed."
EOL

# Make the test runner executable
chmod +x /home/ubuntu/ai_saas_website/run_integration_tests.sh

echo "Integration test setup completed. Run tests with: cd /home/ubuntu/ai_saas_website && ./run_integration_tests.sh"
